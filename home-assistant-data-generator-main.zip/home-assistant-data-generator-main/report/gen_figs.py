"""Generate all paper figures into ./figs (charts from the real engine + diagrams)."""
from __future__ import annotations
import sys, os
from datetime import date
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

sys.path.insert(0, "/home/mooazelsayed/Documents/GitHub/home-assistant-data-generator/backend")
FIG = Path("/tmp/ha-energy-sim/paper/figs"); FIG.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({"font.size": 11, "font.family": "DejaVu Sans", "axes.spemap" if False else "axes.grid": True,
                     "grid.alpha": 0.25, "axes.axisbelow": True, "figure.dpi": 150})

INK = "#1f2530"; VOLT = "#16a34a"; BLUE = "#2563eb"; AMBER = "#d97706"; RED = "#dc2626"; GREY = "#94a3b8"

# ---------------------------------------------------------------- diagrams
def box(ax, x, y, w, h, text, fc="#eef2f7", ec=INK, tc=INK, fs=10):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.08",
                                linewidth=1.3, edgecolor=ec, facecolor=fc))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs, color=tc, wrap=True)

def arrow(ax, x1, y1, x2, y2, color=INK):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=14,
                                 lw=1.3, color=color, shrinkA=2, shrinkB=2))

def fig_architecture():
    fig, ax = plt.subplots(figsize=(9, 2.5)); ax.set_xlim(0, 10); ax.set_ylim(0, 3); ax.axis("off")
    ax.grid(False)
    box(ax, 0.1, 1.0, 1.9, 1.0, "Data Generator\n(FastAPI + NumPy)", fc="#e9f7ef", ec=VOLT)
    box(ax, 2.3, 1.0, 1.7, 1.0, "Dataset bundle\nCSV + HA SQLite", fc="#eef2f7")
    box(ax, 4.3, 1.0, 1.7, 1.0, "HA recorder\nbackfill", fc="#eef2f7")
    box(ax, 6.3, 1.0, 1.7, 1.0, "AppDaemon\nforecast model", fc="#eef7ff", ec=BLUE)
    box(ax, 8.3, 1.0, 1.6, 1.0, "Lovelace\ndashboard", fc="#fff7ed", ec=AMBER)
    for x in (2.0, 4.0, 6.0, 8.0):
        arrow(ax, x, 1.5, x + 0.3, 1.5)
    ax.text(5, 2.45, "Figure 1 — End-to-end system", ha="center", fontsize=11, weight="bold", color=INK)
    fig.savefig(FIG / "fig_architecture.png", bbox_inches="tight"); plt.close(fig)

def fig_pipeline():
    fig, ax = plt.subplots(figsize=(9, 2.7)); ax.set_xlim(0, 10); ax.set_ylim(0, 3.2); ax.axis("off"); ax.grid(False)
    box(ax, 0.1, 1.9, 2.0, 0.9, "Weather\n(Open-Meteo / synthetic)", fc="#eef7ff", ec=BLUE, fs=9)
    box(ax, 0.1, 0.5, 2.0, 0.9, "Occupancy\n(lifestyle preset)", fc="#fef9e7", ec=AMBER, fs=9)
    box(ax, 2.6, 1.2, 2.0, 1.0, "Device archetypes\n(per-hour kWh)", fc="#e9f7ef", ec=VOLT, fs=9)
    box(ax, 5.1, 1.2, 1.6, 1.0, "Sum + noise\n→ gross", fc="#eef2f7", fs=9)
    box(ax, 7.1, 1.2, 1.4, 1.0, "Validate", fc="#eef2f7", fs=9)
    box(ax, 8.8, 1.2, 1.1, 1.0, "Export", fc="#eef2f7", fs=9)
    arrow(ax, 2.1, 2.3, 2.6, 1.9); arrow(ax, 2.1, 0.95, 2.6, 1.5)
    arrow(ax, 4.6, 1.7, 5.1, 1.7); arrow(ax, 6.7, 1.7, 7.1, 1.7); arrow(ax, 8.5, 1.7, 8.8, 1.7)
    ax.text(5, 3.0, "Figure 2 — Simulation pipeline", ha="center", fontsize=11, weight="bold", color=INK)
    fig.savefig(FIG / "fig_pipeline.png", bbox_inches="tight"); plt.close(fig)

# ---------------------------------------------------------------- engine-based charts
def run_engine():
    from src.domain.catalog import DeviceCategory, RoomType, LifestylePreset
    from src.domain.models import DeviceSpec, HouseholdSpec, SimulationConfig
    from src.domain.simulator import simulate
    devs = [
        DeviceSpec("d1", "Fridge", DeviceCategory.REFRIGERATOR, RoomType.KITCHEN, 1.0),
        DeviceSpec("d2", "Air Conditioner", DeviceCategory.AIR_CONDITIONER, RoomType.LIVING_ROOM, 6.0),
        DeviceSpec("d3", "Lighting", DeviceCategory.LIGHTING, RoomType.LIVING_ROOM, 1.5),
        DeviceSpec("d4", "Dishwasher", DeviceCategory.DISHWASHER, RoomType.KITCHEN, 1.0),
    ]
    h = HouseholdSpec(30.03, 31.21, "Africa/Cairo", date(2024, 6, 1), 120,
                      LifestylePreset.FAMILY_WITH_KIDS, 10.0, "EG", master_seed=42)
    return simulate(SimulationConfig(h, tuple(devs)))

def fig_loadprofile(res):
    hours = res.index.hour.to_numpy()
    fig, ax = plt.subplots(figsize=(7, 3.2))
    order = ["Fridge", "Air Conditioner", "Lighting", "Dishwasher"]
    colors = {"Fridge": GREY, "Air Conditioner": BLUE, "Lighting": AMBER, "Dishwasher": VOLT}
    bottom = np.zeros(24)
    for name in order:
        arr = next(a for (n, a) in res.per_device.values() if n == name) if False else None
    # build mean-by-hour per device
    perdev = {nm: a for (nm, a) in res.per_device.values()}
    for name in order:
        arr = perdev[name]
        mean_h = np.array([arr[hours == hh].mean() for hh in range(24)])
        ax.bar(range(24), mean_h, bottom=bottom, label=name, color=colors[name], width=0.9, edgecolor="white", linewidth=0.3)
        bottom += mean_h
    total = np.array([res.gross_kwh[hours == hh].mean() for hh in range(24)])
    ax.plot(range(24), total, color=INK, lw=2, marker="o", ms=3, label="Total (gross)")
    ax.set_xlabel("Hour of day"); ax.set_ylabel("Mean consumption (kWh)")
    ax.set_xticks(range(0, 24, 3)); ax.legend(fontsize=8, ncol=3, loc="upper left", framealpha=0.9)
    ax.set_title("Figure 3 — Mean daily load by device archetype (summer, Cairo)", fontsize=10, weight="bold")
    fig.savefig(FIG / "fig_loadprofile.png", bbox_inches="tight"); plt.close(fig)

def fig_backfill(res):
    # original gross vs reconstructed from cumulative sum (HA backfill = diff of cumsum)
    g = res.gross_kwh[:168]
    recon = np.diff(res.cumulative_kwh[:169], prepend=res.cumulative_kwh[0] - res.gross_kwh[0])[:168]
    t = np.arange(len(g))
    fig, ax = plt.subplots(figsize=(7, 2.8))
    ax.plot(t, g, color=BLUE, lw=2.2, label="Original gross_kwh")
    ax.plot(t, recon, color=RED, lw=1.0, ls="--", label="Reconstructed (HA backfill)")
    ax.set_xlabel("Hour"); ax.set_ylabel("kWh"); ax.legend(fontsize=8)
    ax.set_title("Figure 4 — Backfill fidelity: cumulative-sum diff recovers gross exactly (week 1)", fontsize=9.5, weight="bold")
    fig.savefig(FIG / "fig_backfill.png", bbox_inches="tight"); plt.close(fig)

def fig_shap():
    feats = ["lag_1h", "direct_radiation_wm2", "lag_2h", "hour_cos", "lag_72h"]
    vals = [0.9103, 0.0114, 0.0104, 0.009, 0.0053]
    fig, ax = plt.subplots(figsize=(7, 2.6))
    y = np.arange(len(feats))[::-1]
    ax.barh(y, vals, color=VOLT, edgecolor=INK, linewidth=0.4)
    ax.set_yticks(y); ax.set_yticklabels(feats, fontsize=9)
    for yi, v in zip(y, vals):
        ax.text(v + 0.01, yi, f"{v:.3f}", va="center", fontsize=8)
    ax.set_xlim(0, 1.05); ax.set_xlabel("Mean |SHAP| contribution (kWh)")
    ax.set_title("Figure 5 — Feature importance for today's forecast (SHAP)", fontsize=10, weight="bold")
    fig.savefig(FIG / "fig_shap.png", bbox_inches="tight"); plt.close(fig)

fig_architecture(); fig_pipeline()
res = run_engine()
fig_loadprofile(res); fig_backfill(res); fig_shap()
print("FIGS:", sorted(p.name for p in FIG.glob("*.png")))
