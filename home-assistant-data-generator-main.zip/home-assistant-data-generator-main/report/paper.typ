#set page(paper: "a4", margin: (x: 1.8cm, y: 1.9cm), numbering: "1")
#set text(size: 10pt, fill: rgb("#1f2530"))
#set par(justify: true, leading: 0.62em)
#set terms(separator: [ — ], hanging-indent: 1.2em, spacing: 0.45em)
#show heading.where(level: 1): it => block(above: 1.1em, below: 0.6em, text(size: 13pt, fill: rgb("#16a34a"), weight: "bold", it.body))
#show heading.where(level: 2): it => block(above: 0.8em, below: 0.4em, text(size: 11pt, weight: "bold", it.body))
#show figure.caption: it => text(size: 8.5pt, fill: rgb("#4e596f"), it)
#set figure(gap: 0.5em)

#let key(body) = block(fill: rgb("#eef7ff"), inset: 7pt, radius: 5pt, width: 100%, stroke: 0.5pt + rgb("#bcd"), text(size: 9.5pt, body))
// "where:" glossary that sits right under an equation
#let where(body) = block(inset: (left: 12pt, top: 1pt, bottom: 4pt), text(size: 8.8pt, fill: rgb("#40485a"))[#text(style: "italic")[where:] #body])

#align(center)[
  #text(size: 17pt, weight: "bold")[Synthetic Data Generation for Home-Assistant Energy Forecasting]
  #v(2pt)
  #text(size: 10pt, fill: rgb("#4e596f"))[A technical report — system, simulation physics, model, backfilling, live forecasting, and anomaly detection]
  #v(2pt)
  #text(size: 9pt, fill: rgb("#637088"))[June 2026]
]
#v(4pt)

#key[*In one paragraph.* A live forecast model needs months of history to train — which a new install doesn't have. We *generate realistic synthetic history* from a description of the home (rooms, devices, lifestyle, location), load it into Home Assistant exactly as if it were recorded, and let the existing forecasting app train on it. The result is a working 48-hour load forecast, prediction bands, an explanation of *why*, and anomaly detection — all on day one.]

#v(3pt)
*A note on the symbols.* Throughout, $d$ means "a device" and $t$ means "an hour". Every equation is followed by a plain-language list of what each symbol means.

= 1. System overview

The pipeline has five stages (Fig. 1). A *generator* turns a home description into an hour-by-hour energy history. That history is packaged as the same CSV + SQLite formats Home Assistant (HA) records natively, so HA's *backfill* loads it without modification. An *AppDaemon* app trains a model on it and publishes forecast sensors, which a *dashboard* visualises.

#figure(image("figs/fig_architecture.png", width: 96%), caption: [The five stages, left to right. The generated dataset is format-compatible with HA, so no glue code is needed between stages.])

= 2. Data generation: the physics and the math

Each device is simulated on its own, hour by hour, then all devices are added up. Every device follows one of five *behavioural archetypes*. You supply only a typical energy figure (e.g. kWh per day); the archetype decides *when* that energy is spent across the day (Fig. 2).

#figure(image("figs/fig_pipeline.png", width: 96%), caption: [Per-device hourly profiles are driven by weather and occupancy, summed, perturbed with noise, validated, and exported.])

== Calibration: your estimate sets the total, the archetype sets the shape
The archetype first produces a rough hourly *shape*; we then scale that shape so the device's energy adds up to exactly what you entered:
$ P_(d,t) = C_d times s_(d,t), quad quad C_d = E_d \/ (sum_t s_(d,t)). $
#where[
/ $P_(d,t)$: the final energy used by device $d$ in hour $t$ (kWh)
/ $s_(d,t)$: the archetype's raw hourly "shape" for the device (a unit-less weight that says *when* energy is used)
/ $E_d$: the *total* energy you entered for the device over the whole period (kWh)
/ $C_d$: a single scaling number, chosen so the scaled shape adds up to exactly $E_d$
/ $sum_t s_(d,t)$: the shape added up over all hours
]

== Thermostatic devices (heat pump, A/C, water heater)
These follow the weather. The home only needs *heating* when it is colder than a "balance" temperature; the colder it is, the more it needs:
$ "heat-need"_t = max(0, space T_"bal" - T_t), quad quad P_(d,t) = k_d times "heat-need"_t \/ "COP"(T_t), $
$ "COP"(T) = "clip"(3.5 + 0.05 (T - 7), space 1.8, space 4.5). $
#where[
/ $T_t$: the outdoor temperature in hour $t$ (°C)
/ $T_"bal"$: the "balance" temperature below which heating is needed (about 15 °C); above it, no heating
/ $"heat-need"_t$: how many degrees below balance it is — 0 when warm (this is the "heating demand")
/ $"COP"(T)$: the heat pump's efficiency at temperature $T$ — kWh of heat delivered per kWh of electricity; it drops when it is cold, so electricity use rises
/ $k_d$: the device's scaling constant (from calibration above)
/ $"clip"(x, space "low", space "high")$: keep $x$ within the low–high range
]
A cooling term works the same way above a higher temperature. Buildings also change temperature *slowly*, so we smooth the demand with a moving average:
$ tilde(P)_t = alpha space P_t + (1 - alpha) space tilde(P)_(t-1). $
#where[
/ $tilde(P)_t$: the *smoothed* energy for hour $t$ (adds thermal "inertia")
/ $alpha$: smoothing strength, between 0 and 1 (about 0.3); higher reacts faster to weather
/ $tilde(P)_(t-1)$: the smoothed value from the previous hour
]
This smoothing is *the source of the seasonal signal* the model later learns from.

== Occupancy-driven devices (lights, TV, oven, computer)
These scale with how active the household is, and follow a daily rhythm. Lighting additionally only matters when it is dark:
$ P_(d,t) = "occ"(t) times "tod"_d (t) times g_t, quad quad g_t = "clip"(1 - "sun"_t \/ 60, space 0.1, space 1). $
#where[
/ $"occ"(t)$: how active the household is in hour $t$, from 0 (asleep / away) to 1 (fully active) — set by the chosen lifestyle preset
/ $"tod"_d (t)$: the device's typical time-of-day pattern (e.g. lights and TV peak in the evening) — a unit-less weight
/ $g_t$: a "daylight gate" used only for lighting — near 1 when dark, near 0 in bright sun
/ $"sun"_t$: minutes of sunshine in hour $t$ (0 to 60)
]
This is *the source of the daily cycle and the weekday/weekend difference*. (Always-on devices like the fridge are a flat baseline; cyclic devices like the dishwasher are discrete runs placed in likely hours; EV charging is evening blocks capped at the charger's power.)

== Adding realistic randomness, then combining
No two days are identical, so each device's value is multiplied by a random factor that *averages 1* (it adds jitter without changing the long-run total, and can never go negative):
$ hat(P)_(d,t) = P_(d,t) times m_(d,t), quad m_(d,t) ~ "LogNormal with mean " 1 " and spread " sigma, quad sigma = sqrt(sigma_d^2 + (a\/100)^2). $
#where[
/ $hat(P)_(d,t)$: the device's energy after adding randomness (kWh)
/ $m_(d,t)$: the random multiplier — its average is exactly 1, so totals stay correct
/ $sigma$: how large the random swings are
/ $sigma_d$: the device's *natural* variability (a fridge is steady; an oven is bursty)
/ $a$: the ± error allowance you set on the slider (e.g. $a = 10$ means ±10%)
]
Finally all devices are added up for each hour and kept within physical limits:
$ "gross"_t = "clip"(eta_t times sum_d hat(P)_(d,t), space 0.01, space 50) quad "(kWh)". $
#where[
/ $"gross"_t$: total household electricity in hour $t$ (kWh) — *this is what the forecast model trains on*
/ $sum_d hat(P)_(d,t)$: the sum of all devices in that hour
/ $eta_t$: a small whole-house random factor (about 1) so the noise is realistically correlated
/ $"clip"(dot, 0.01, 50)$: keep every hour physically sensible — never exactly 0, never above 50 kWh
]

#figure(image("figs/fig_loadprofile.png", width: 88%), caption: [Real output of the generator (summer, Cairo). The fridge is a flat baseline, the A/C tracks afternoon heat, lighting peaks morning and evening, and the dishwasher runs in the evening — the equations above, made visible.])

= 3. The model and how it is trained

== Backfilling: turning the dataset into trainable history
HA records energy as a *cumulative meter* — a number that only ever goes up. The generated SQLite carries that same cumulative column, so HA recovers each hour's usage just by subtracting the previous reading:
$ "gross"_t = C_t - C_(t-1). $
#where[
/ $C_t$: the cumulative meter reading at hour $t$ (kWh) — always increasing, the way HA stores energy
/ $C_t - C_(t-1)$: this hour's reading minus last hour's = the energy used during hour $t$
]
This recovers the original signal *exactly* (Fig. 4): the generated data is indistinguishable from genuinely recorded data.

#figure(image("figs/fig_backfill.png", width: 88%), caption: [Subtracting consecutive cumulative readings recovers the original per-hour series row-for-row (the two lines coincide).])

== The forecaster
A *gradient-boosted tree* model (LightGBM, with a scikit-learn fallback). It does not predict kWh directly; it predicts the *logarithm* of consumption, which keeps rare big spikes from dominating, then converts back:
$ y_t = log(1 + "gross"_t), quad quad hat("gross")_t = exp(hat(y)_t) - 1. $
#where[
/ $y_t$: the quantity the model actually learns (the log of consumption)
/ $hat(y)_t$: the model's prediction of $y$ for hour $t$ (the hat $hat(quad)$ means "predicted")
/ $hat("gross")_t$: that prediction converted back into kWh
/ $log$, $exp$: the natural logarithm and its inverse
]
*Inputs (features)* the model is given for each hour: calendar (hour, day-of-week, month, plus smooth $sin$/$cos$ versions so "23:00" sits next to "00:00"); weather (temperature, solar radiation, heating/cooling demand); *lags* — consumption from $1, 2, 24, ..., 168$ hours earlier (a "lag" is simply a past value used to predict the present); and rolling averages. Two extra *quantile* models predict a low (10%) and high (90%) value, which become the Min/Max band. The model retrains weekly so it improves as real data accumulates.

== Live forecasting
Every cycle the app fetches a 48-hour weather forecast, builds the same features for the upcoming hours, predicts, and publishes sensors: *today*, *tomorrow* and *next-3h* totals, each with a low–high band.

= 4. Anomaly detection

After each forecast, the app checks how far reality drifted from the prediction. If the gap is much larger than the usual gap, it raises a flag:
$ r_t = "actual"_t - hat("gross")_t, quad quad "alert when " |r_t| > k times sigma_r. $
#where[
/ $r_t$: the *residual* — how far actual use was from the forecast in hour $t$ (kWh)
/ $"actual"_t$: what the real meter recorded in hour $t$
/ $hat("gross")_t$: what the model predicted for hour $t$
/ $|r_t|$: the size of the gap, ignoring whether it was over or under
/ $sigma_r$: the *typical* size of recent gaps (their standard deviation)
/ $k$: a sensitivity dial (e.g. $k = 3$ → only alert when the gap is 3× the usual)
]
When this trips, `binary_sensor.energy_forecast_unusual_consumption` turns on and exposes $r_t$, $sigma_r$ and the threshold as attributes — in words, "you used much more (or less) than expected."

= 5. The dashboard, element by element

#grid(columns: (1.15fr, 1fr), gutter: 12pt,
[
  #figure(image("figs/fig_dashboard.png", width: 100%), caption: [The Energy Forecast page (callouts 1–4).])
],
[
  *1 — Forecast tiles.* Predicted energy for *Today* (Heute), *Tomorrow* (Morgen) and the *next 3h*, each with *Min/Max* — the 10%/90% band from the two quantile models. A wider band means the model is less certain.

  *2 — Unusual-consumption status.* The anomaly check from §4 — a green *"No unusual consumption"* by default, flipping to a red alert when $|r_t| > k sigma_r$.

  *3 — "What Drives This Forecast?"* A plain-language reading of the model's feature contributions — what pushed today's number up or down.

  *4 — Feature-importance table.* The same, quantified: each input's contribution (kWh) to today's prediction. Here #raw("lag_1h") (the most recent hour's consumption) dominates — see Fig. 5.
])

#figure(image("figs/fig_shap.png", width: 78%), caption: [Contribution of each input to today's forecast. The most recent hour's consumption is by far the strongest driver; solar radiation and time-of-day add small corrections.])

The page also carries two charts. *Forecast trend* (Fig. 6) is the recorded history of the forecast sensors — how the predictions for today / tomorrow / next-3h have changed over time (it fills out to a trailing window as days pass). *Actual consumption* is a native chart of the real meter's hourly use, for side-by-side comparison.

#figure(image("figs/fig_trend.png", width: 64%), caption: [Forecast-trend chart: the evolving predicted totals. It starts when the sensors were first published and extends forward in time.])

#v(3pt)
#key[*Bottom line.* Describe the home → get a physically-plausible energy history → HA trains on it as if it were real → you immediately get a 48-hour forecast with uncertainty bands, a plain-language explanation, and anomaly alerts, without waiting months for data to accrue.]
