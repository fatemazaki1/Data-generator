import type { Config } from "tailwindcss";

export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: {
          50: "#f6f7f9", 100: "#eceef2", 200: "#d4d9e2", 300: "#aeb7c7",
          400: "#8290a6", 500: "#637088", 600: "#4e596f", 700: "#40485a",
          800: "#373e4c", 900: "#1f2530", 950: "#12161d",
        },
        volt: {
          50: "#f0fdf4", 100: "#dcfce7", 200: "#bbf7d0", 300: "#86efac",
          400: "#4ade80", 500: "#22c55e", 600: "#16a34a", 700: "#15803d",
          800: "#166534", 900: "#14532d",
        },
        amber: {
          400: "#fbbf24", 500: "#f59e0b", 600: "#d97706",
        },
      },
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"],
        mono: ["ui-monospace", "SFMono-Regular", "Menlo", "monospace"],
      },
      boxShadow: {
        card: "0 1px 2px rgba(16,22,29,0.04), 0 4px 16px rgba(16,22,29,0.06)",
      },
    },
  },
  plugins: [],
} satisfies Config;
