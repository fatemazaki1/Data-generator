import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Database, Download, Home, Plus, Trash2 } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { Badge, Button, Card, Spinner } from "@/components/ui";
import { api } from "@/lib/api";
import type { SimulationRun } from "@/lib/types";

const statusTone = {
  completed: "green",
  running: "blue",
  queued: "neutral",
  failed: "red",
} as const;

export function Dashboard() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const households = useQuery({ queryKey: ["households"], queryFn: api.listHouseholds });
  const runs = useQuery({
    queryKey: ["runs"],
    queryFn: api.listRuns,
    refetchInterval: (q) =>
      (q.state.data as SimulationRun[] | undefined)?.some(
        (r) => r.status === "running" || r.status === "queued",
      )
        ? 2000
        : false,
  });

  const deleteRun = useMutation({
    mutationFn: api.deleteRun,
    onSuccess: () => qc.invalidateQueries({ queryKey: ["runs"] }),
  });
  const deleteHousehold = useMutation({
    mutationFn: api.deleteHousehold,
    onSuccess: () => qc.invalidateQueries({ queryKey: ["households"] }),
  });

  return (
    <div className="space-y-10">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Your datasets</h1>
          <p className="mt-1 text-sm text-ink-500">
            Generate realistic energy histories to train ha-energy-forecast.
          </p>
        </div>
        <Button onClick={() => navigate("/new")}>
          <Plus className="h-4 w-4" /> New dataset
        </Button>
      </div>

      <section>
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-ink-400">
          Generation runs
        </h2>
        {runs.isLoading ? (
          <Spinner />
        ) : runs.data && runs.data.length > 0 ? (
          <div className="space-y-2">
            {runs.data.map((run) => (
              <div key={run.id} className="card flex items-center justify-between px-5 py-4">
                <div className="flex items-center gap-4">
                  <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-ink-100 text-ink-500">
                    <Database className="h-5 w-5" />
                  </span>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{run.n_days}-day dataset</span>
                      <Badge tone={statusTone[run.status]}>{run.status}</Badge>
                    </div>
                    <p className="text-xs text-ink-400">
                      seed {run.seed} · {new Date(run.created_at).toLocaleString()}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {run.status === "completed" && (
                    <Button variant="secondary" onClick={() => api.download(run.id)}>
                      <Download className="h-4 w-4" /> Download
                    </Button>
                  )}
                  <Link to={`/runs/${run.id}`}>
                    <Button variant="ghost">Details</Button>
                  </Link>
                  <Button
                    variant="ghost"
                    aria-label="Delete run"
                    loading={deleteRun.isPending && deleteRun.variables === run.id}
                    onClick={() => {
                      if (confirm("Delete this dataset and its generated files?"))
                        deleteRun.mutate(run.id);
                    }}
                  >
                    <Trash2 className="h-4 w-4 text-red-500" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <Card className="text-center text-sm text-ink-500">
            No runs yet. Create your first dataset to get started.
          </Card>
        )}
      </section>

      <section>
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-ink-400">
          Saved households
        </h2>
        {households.isLoading ? (
          <Spinner />
        ) : households.data && households.data.length > 0 ? (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {households.data.map((h) => (
              <Card key={h.id} className="flex items-start justify-between">
                <Link to={`/households/${h.id}`} className="group flex items-start gap-3">
                  <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-volt-100 text-volt-700">
                    <Home className="h-4 w-4" />
                  </span>
                  <span>
                    <p className="font-medium group-hover:text-volt-700">{h.name}</p>
                    <p className="text-xs text-ink-400">{h.lifestyle.replace(/_/g, " ")}</p>
                  </span>
                </Link>
                <button
                  aria-label="Delete household"
                  className="text-ink-300 hover:text-red-600"
                  onClick={() => {
                    if (confirm(`Delete household "${h.name}"?`)) deleteHousehold.mutate(h.id);
                  }}
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="text-center text-sm text-ink-500">No saved households yet.</Card>
        )}
      </section>
    </div>
  );
}
