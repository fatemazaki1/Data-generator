import { useQuery } from "@tanstack/react-query";
import { AlertTriangle, ArrowLeft, CheckCircle2, Download, XCircle } from "lucide-react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { Badge, Button, Card, Spinner } from "@/components/ui";
import { api } from "@/lib/api";
import { cn } from "@/lib/cn";

const PHASES = ["weather", "simulate", "validate", "export", "completed"];
const PHASE_LABEL: Record<string, string> = {
  queued: "Queued",
  weather: "Fetching weather",
  simulate: "Simulating consumption",
  validate: "Validating output",
  export: "Exporting artifacts",
  completed: "Completed",
  failed: "Failed",
};

export function RunStatus() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const run = useQuery({
    queryKey: ["run", id],
    queryFn: () => api.getRun(id!),
    refetchInterval: (q) => {
      const s = q.state.data?.status;
      return s === "running" || s === "queued" ? 1000 : false;
    },
  });

  if (run.isLoading || !run.data) return <Spinner />;
  const r = run.data;
  const activeIdx = PHASES.indexOf(r.phase);

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <Button variant="ghost" onClick={() => navigate("/")}>
        <ArrowLeft className="h-4 w-4" /> Back to datasets
      </Button>

      <Card className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-lg font-semibold">{r.n_days}-day dataset</h1>
            <p className="text-xs text-ink-400">seed {r.seed}</p>
          </div>
          <Badge
            tone={
              r.status === "completed"
                ? "green"
                : r.status === "failed"
                  ? "red"
                  : "blue"
            }
          >
            {r.status}
          </Badge>
        </div>

        {(r.status === "running" || r.status === "queued") && (
          <div className="space-y-4">
            <div className="h-2 w-full overflow-hidden rounded-full bg-ink-100">
              <div
                className="h-full rounded-full bg-volt-500 transition-all"
                style={{ width: `${r.progress}%` }}
              />
            </div>
            <ol className="space-y-2">
              {PHASES.map((phase, i) => (
                <li key={phase} className="flex items-center gap-3 text-sm">
                  <span
                    className={cn(
                      "h-2 w-2 rounded-full",
                      i < activeIdx && "bg-volt-500",
                      i === activeIdx && "bg-volt-500 ring-4 ring-volt-500/20",
                      i > activeIdx && "bg-ink-200",
                    )}
                  />
                  <span className={i <= activeIdx ? "text-ink-800" : "text-ink-400"}>
                    {PHASE_LABEL[phase]}
                  </span>
                </li>
              ))}
            </ol>
          </div>
        )}

        {r.status === "completed" && r.validation && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-volt-700">
              <CheckCircle2 className="h-5 w-5" />
              <span className="font-medium">Dataset ready and validated</span>
            </div>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <Stat label="Rows" value={r.validation.stats.rows?.toLocaleString()} />
              <Stat label="Total kWh" value={r.validation.stats.total_kwh?.toFixed(0)} />
              <Stat label="Mean daily kWh" value={r.validation.stats.mean_daily_kwh?.toFixed(1)} />
              <Stat label="Peak hour kWh" value={r.validation.stats.peak_hour_kwh?.toFixed(2)} />
            </div>
            {r.validation.warnings.length > 0 && (
              <div className="rounded-lg bg-amber-400/10 p-3">
                <div className="mb-1 flex items-center gap-2 text-sm font-medium text-amber-600">
                  <AlertTriangle className="h-4 w-4" /> Learnability notes
                </div>
                <ul className="list-inside list-disc text-xs text-amber-700">
                  {r.validation.warnings.map((w, i) => (
                    <li key={i}>{w}</li>
                  ))}
                </ul>
              </div>
            )}
            <Button className="w-full" onClick={() => api.download(r.id)}>
              <Download className="h-4 w-4" /> Download dataset (.zip)
            </Button>
            <p className="text-center text-xs text-ink-400">
              Includes energy_history.csv, weather.csv, per-appliance CSVs, a HA
              statistics SQLite, and an apps.yaml snippet.
            </p>
          </div>
        )}

        {r.status === "failed" && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-red-600">
              <XCircle className="h-5 w-5" />
              <span className="font-medium">Generation failed</span>
            </div>
            <p className="text-sm text-ink-600">{r.error_message}</p>
            {r.validation?.errors?.length ? (
              <ul className="list-inside list-disc text-xs text-red-600">
                {r.validation.errors.map((e, i) => (
                  <li key={i}>{e}</li>
                ))}
              </ul>
            ) : null}
            <Link to="/new">
              <Button variant="secondary">Try again</Button>
            </Link>
          </div>
        )}
      </Card>
    </div>
  );
}

function Stat({ label, value }: { label: string; value?: string }) {
  return (
    <div className="rounded-lg bg-ink-50 px-4 py-3">
      <p className="text-xs text-ink-400">{label}</p>
      <p className="text-lg font-semibold">{value ?? "—"}</p>
    </div>
  );
}
