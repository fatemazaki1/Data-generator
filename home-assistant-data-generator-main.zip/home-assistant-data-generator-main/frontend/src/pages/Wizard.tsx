import { useMutation, useQuery } from "@tanstack/react-query";
import { ArrowLeft, ArrowRight, Check, Plus, Trash2, Zap } from "lucide-react";
import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Badge, Button, Card, Field, Input, Select } from "@/components/ui";
import { api } from "@/lib/api";
import { cn } from "@/lib/cn";
import type { Catalog, DeviceInput, EstimatePeriod, RoomInput } from "@/lib/types";

const PERIOD_DAYS: Record<EstimatePeriod, number> = {
  day: 1,
  week: 7,
  month: 30.44,
  year: 365.25,
};

const STEPS = ["Household", "Rooms & devices", "Generation", "Review"];

export function Wizard() {
  const navigate = useNavigate();
  const catalog = useQuery({ queryKey: ["catalog"], queryFn: api.catalog });
  const [step, setStep] = useState(0);

  const [name, setName] = useState("My Home");
  const [lat, setLat] = useState("47.0");
  const [lon, setLon] = useState("8.0");
  const [timezone, setTimezone] = useState("Europe/Zurich");
  const [lifestyle, setLifestyle] = useState("family_with_kids");
  const [country, setCountry] = useState("CH");
  const [rooms, setRooms] = useState<RoomInput[]>([]);

  const [startDate, setStartDate] = useState("2024-01-01");
  const [nDays, setNDays] = useState(180);
  const [errorPct, setErrorPct] = useState(10);

  const generate = useMutation({
    mutationFn: async () => {
      const household = await api.createHousehold({
        name,
        latitude: parseFloat(lat),
        longitude: parseFloat(lon),
        timezone,
        lifestyle,
        holidays_country: country,
        rooms,
      });
      return api.createRun({
        household_id: household.id,
        start_date: startDate,
        n_days: nDays,
        error_allowance_pct: errorPct,
      });
    },
    onSuccess: (run) => navigate(`/runs/${run.id}`),
  });

  const dailyTotal = useMemo(() => {
    let sum = 0;
    for (const r of rooms)
      for (const d of r.devices) sum += d.kwh_estimate / PERIOD_DAYS[d.estimate_period];
    return sum;
  }, [rooms]);

  const deviceCount = rooms.reduce((n, r) => n + r.devices.length, 0);
  const canGenerate = deviceCount > 0;

  if (catalog.isLoading || !catalog.data) {
    return <p className="text-sm text-ink-500">Loading catalog…</p>;
  }

  return (
    <div className="mx-auto max-w-3xl">
      <Stepper step={step} />

      <div className="mt-6">
        {step === 0 && (
          <Card className="space-y-4">
            <h2 className="text-lg font-semibold">Household</h2>
            <Field label="Name">
              <Input value={name} onChange={(e) => setName(e.target.value)} />
            </Field>
            <div className="grid grid-cols-2 gap-4">
              <Field label="Latitude" hint="Drives the weather model">
                <Input value={lat} onChange={(e) => setLat(e.target.value)} />
              </Field>
              <Field label="Longitude">
                <Input value={lon} onChange={(e) => setLon(e.target.value)} />
              </Field>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Field label="Timezone">
                <Input value={timezone} onChange={(e) => setTimezone(e.target.value)} />
              </Field>
              <Field label="Holiday country (ISO)">
                <Input
                  value={country}
                  onChange={(e) => setCountry(e.target.value.toUpperCase())}
                  maxLength={2}
                />
              </Field>
            </div>
            <Field label="Lifestyle" hint="Shapes occupancy and the daily/weekly load curve">
              <Select value={lifestyle} onChange={(e) => setLifestyle(e.target.value)}>
                {catalog.data.lifestyles.map((l) => (
                  <option key={l.preset} value={l.preset}>
                    {l.label}
                  </option>
                ))}
              </Select>
            </Field>
          </Card>
        )}

        {step === 1 && (
          <RoomsStep catalog={catalog.data} rooms={rooms} setRooms={setRooms} dailyTotal={dailyTotal} />
        )}

        {step === 2 && (
          <Card className="space-y-4">
            <h2 className="text-lg font-semibold">Generation settings</h2>
            <div className="grid grid-cols-2 gap-4">
              <Field label="Start date">
                <Input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
              </Field>
              <Field label="Number of days" hint="≥ 100 rows needed to train; 180+ recommended">
                <Input
                  type="number"
                  min={5}
                  max={1095}
                  value={nDays}
                  onChange={(e) => setNDays(parseInt(e.target.value || "0", 10))}
                />
              </Field>
            </div>
            <Field
              label={`Error / noise allowance: ±${errorPct}%`}
              hint="Random variation added to make consumption realistic"
            >
              <input
                type="range"
                min={0}
                max={30}
                value={errorPct}
                onChange={(e) => setErrorPct(parseInt(e.target.value, 10))}
                className="w-full accent-volt-600"
              />
            </Field>
          </Card>
        )}

        {step === 3 && (
          <Card className="space-y-4">
            <h2 className="text-lg font-semibold">Review & generate</h2>
            <dl className="grid grid-cols-2 gap-y-3 text-sm">
              <Summary label="Household" value={name} />
              <Summary label="Location" value={`${lat}, ${lon}`} />
              <Summary label="Lifestyle" value={lifestyle.replace(/_/g, " ")} />
              <Summary label="Rooms" value={`${rooms.length}`} />
              <Summary label="Devices" value={`${deviceCount}`} />
              <Summary label="Horizon" value={`${nDays} days from ${startDate}`} />
              <Summary label="Est. daily load" value={`${dailyTotal.toFixed(1)} kWh`} />
              <Summary label="Noise" value={`±${errorPct}%`} />
            </dl>
            {!canGenerate && (
              <p className="text-sm text-red-600">Add at least one device before generating.</p>
            )}
            {generate.isError && (
              <p className="text-sm text-red-600">
                {(generate.error as Error).message || "Generation failed."}
              </p>
            )}
          </Card>
        )}
      </div>

      <div className="mt-6 flex items-center justify-between">
        <Button
          variant="ghost"
          onClick={() => (step === 0 ? navigate("/") : setStep(step - 1))}
        >
          <ArrowLeft className="h-4 w-4" /> {step === 0 ? "Cancel" : "Back"}
        </Button>
        {step < STEPS.length - 1 ? (
          <Button onClick={() => setStep(step + 1)} disabled={step === 1 && !canGenerate}>
            Next <ArrowRight className="h-4 w-4" />
          </Button>
        ) : (
          <Button onClick={() => generate.mutate()} loading={generate.isPending} disabled={!canGenerate}>
            <Zap className="h-4 w-4" /> Generate dataset
          </Button>
        )}
      </div>
    </div>
  );
}

function Stepper({ step }: { step: number }) {
  return (
    <div className="flex items-center gap-2">
      {STEPS.map((label, i) => (
        <div key={label} className="flex flex-1 items-center gap-2">
          <span
            className={cn(
              "flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-semibold",
              i < step && "bg-volt-600 text-white",
              i === step && "bg-ink-900 text-white",
              i > step && "bg-ink-200 text-ink-500",
            )}
          >
            {i < step ? <Check className="h-4 w-4" /> : i + 1}
          </span>
          <span className={cn("text-sm", i === step ? "font-medium text-ink-900" : "text-ink-400")}>
            {label}
          </span>
          {i < STEPS.length - 1 && <div className="h-px flex-1 bg-ink-200" />}
        </div>
      ))}
    </div>
  );
}

function Summary({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-ink-400">{label}</dt>
      <dd className="font-medium capitalize">{value}</dd>
    </div>
  );
}

function RoomsStep({
  catalog,
  rooms,
  setRooms,
  dailyTotal,
}: {
  catalog: Catalog;
  rooms: RoomInput[];
  setRooms: (r: RoomInput[]) => void;
  dailyTotal: number;
}) {
  const categoryInfo = (cat: string) => catalog.categories.find((c) => c.category === cat);

  const addRoom = (roomType: string) => {
    const info = catalog.room_types.find((r) => r.room_type === roomType)!;
    const label = roomType.replace(/_/g, " ");
    const devices: DeviceInput[] = info.default_categories.map((cat) => {
      const ci = categoryInfo(cat)!;
      return { name: ci.label, category: cat, kwh_estimate: ci.default_kwh_per_day, estimate_period: "day" };
    });
    setRooms([...rooms, { name: label.charAt(0).toUpperCase() + label.slice(1), room_type: roomType, devices }]);
  };

  const update = (next: RoomInput[]) => setRooms([...next]);

  return (
    <div className="space-y-4">
      <Card className="space-y-3">
        <h2 className="text-lg font-semibold">Add a room</h2>
        <div className="flex flex-wrap gap-2">
          {catalog.room_types.map((rt) => (
            <button
              key={rt.room_type}
              onClick={() => addRoom(rt.room_type)}
              className="rounded-full border border-ink-200 px-3 py-1.5 text-sm text-ink-700 transition hover:border-volt-500 hover:bg-volt-50"
            >
              <Plus className="mr-1 inline h-3.5 w-3.5" />
              {rt.room_type.replace(/_/g, " ")}
            </button>
          ))}
        </div>
      </Card>

      {rooms.map((room, ri) => (
        <Card key={ri} className="space-y-3">
          <div className="flex items-center justify-between">
            <Input
              value={room.name}
              onChange={(e) => {
                rooms[ri].name = e.target.value;
                update(rooms);
              }}
              className="max-w-xs font-medium"
            />
            <Button
              variant="danger"
              onClick={() => update(rooms.filter((_, i) => i !== ri))}
            >
              <Trash2 className="h-4 w-4" /> Remove
            </Button>
          </div>

          <div className="space-y-2">
            {room.devices.map((dev, di) => (
              <div key={di} className="grid grid-cols-12 items-center gap-2">
                <Input
                  className="col-span-4"
                  value={dev.name}
                  onChange={(e) => {
                    rooms[ri].devices[di].name = e.target.value;
                    update(rooms);
                  }}
                />
                <Select
                  className="col-span-4"
                  value={dev.category}
                  onChange={(e) => {
                    rooms[ri].devices[di].category = e.target.value;
                    update(rooms);
                  }}
                >
                  {catalog.categories.map((c) => (
                    <option key={c.category} value={c.category}>
                      {c.label}
                    </option>
                  ))}
                </Select>
                <Input
                  type="number"
                  step="0.1"
                  min={0}
                  className="col-span-2"
                  value={dev.kwh_estimate}
                  onChange={(e) => {
                    rooms[ri].devices[di].kwh_estimate = parseFloat(e.target.value || "0");
                    update(rooms);
                  }}
                />
                <Select
                  className="col-span-1"
                  value={dev.estimate_period}
                  onChange={(e) => {
                    rooms[ri].devices[di].estimate_period = e.target.value as EstimatePeriod;
                    update(rooms);
                  }}
                >
                  <option value="day">/day</option>
                  <option value="week">/wk</option>
                  <option value="month">/mo</option>
                  <option value="year">/yr</option>
                </Select>
                <button
                  className="col-span-1 text-ink-400 hover:text-red-600"
                  onClick={() => {
                    rooms[ri].devices.splice(di, 1);
                    update(rooms);
                  }}
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
            <Button
              variant="ghost"
              onClick={() => {
                const c = catalog.categories[0];
                rooms[ri].devices.push({
                  name: c.label,
                  category: c.category,
                  kwh_estimate: c.default_kwh_per_day,
                  estimate_period: "day",
                });
                update(rooms);
              }}
            >
              <Plus className="h-4 w-4" /> Add device
            </Button>
          </div>
        </Card>
      ))}

      {rooms.length > 0 && (
        <div className="flex items-center justify-between rounded-xl bg-ink-900 px-5 py-4 text-white">
          <span className="text-sm text-ink-300">Estimated household load</span>
          <Badge tone="green">{dailyTotal.toFixed(1)} kWh / day</Badge>
        </div>
      )}
    </div>
  );
}
