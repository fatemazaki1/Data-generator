import { Zap } from "lucide-react";
import { useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { Button, Field, Input } from "@/components/ui";
import { useAuth } from "@/lib/auth";

export function Login() {
  const { username, login, ready } = useAuth();
  const navigate = useNavigate();
  const [u, setU] = useState("");
  const [p, setP] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (ready && username) return <Navigate to="/" replace />;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await login(u, p);
      navigate("/");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign in failed.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-ink-950 px-6">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex flex-col items-center text-center">
          <span className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-volt-500 text-ink-950">
            <Zap className="h-7 w-7" />
          </span>
          <h1 className="text-xl font-semibold text-white">Energy Data Generator</h1>
          <p className="mt-1 text-sm text-ink-400">
            Synthetic Home Assistant energy datasets
          </p>
        </div>
        <form onSubmit={submit} className="card space-y-4 p-6">
          <Field label="Username">
            <Input value={u} onChange={(e) => setU(e.target.value)} autoFocus required />
          </Field>
          <Field label="Password">
            <Input
              type="password"
              value={p}
              onChange={(e) => setP(e.target.value)}
              required
            />
          </Field>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <Button type="submit" className="w-full" loading={loading}>
            Sign in
          </Button>
        </form>
      </div>
    </div>
  );
}
