import { useMutation, useQuery } from "@tanstack/react-query";
import { ArrowLeft, MapPin, Trash2, Zap } from "lucide-react";
import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Badge, Button, Card, Field, Input, Spinner } from "@/components/ui";
import { api } from "@/lib/api";

const PERIOD_DAYS: Record<string, number> = { day: 1, week: 7, month: 30.44, year: 365.25 };

export function HouseholdDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const household = useQuery({ queryKey: ["household", id], queryFn: () => api.getHousehold(id!) });

  const [startDate, setStartDate] = useState("2024-01-01");
  const [nDays, setNDays] = useState(180);
  const [errorPct, setErrorPct] = useState(10);

  const generate = useMutation({
    mutationFn: () =>
      api.createRun({
        household_id: id!,
        start_date: startDate,
        n_days: nDays,
        error_allowance_pct: errorPct,
      }),
    onSuccess: (run) => navigate(`/runs/${run.id}`),
  });
  const remove = useMutation({
    mutationFn: () => api.deleteHousehold(id!),
    onSuccess: () => navigate("/"),
  });

  if (household.isLoading || !household.data) return <Spinner />;
  const h = household.data;
  const dailyTotal = h.rooms.reduce(
    (sum, r) =>
      sum + r.devices.reduce((s, d) => s + d.kwh_estimate / PERIOD_DAYS[d.estimate_period], 0),
    0,
  );
  const deviceCount = h.rooms.reduce((n, r) => n + r.devices.length, 0);

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <Button variant="ghost" onClick={() => navigate("/")}>
        <ArrowLeft className="h-4 w-4" /> Back to datasets
      </Button>

      <Card className="space-y-4">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-xl font-semibold">{h.name}</h1>
            <p className="mt-1 flex items-center gap-1 text-sm text-ink-500">
              <MapPin className="h-3.5 w-3.5" /> {h.latitude}, {h.longitude} · {h.timezone}
            </p>
          </div>
          <Button
            variant="danger"
            loading={remove.isPending}
            onClick={() => {
              if (confirm(`Delete household "${h.name}"? This cannot be undone.`)) remove.mutate();
            }}
          >
            <Trash2 className="h-4 w-4" /> Delete
          </Button>
        </div>
        <div className="flex flex-wrap gap-2">
          <Badge tone="green">{h.lifestyle.replace(/_/g, " ")}</Badge>
          <Badge>{h.rooms.length} rooms</Badge>
          <Badge>{deviceCount} devices</Badge>
          <Badge tone="blue">{dailyTotal.toFixed(1)} kWh/day est.</Badge>
        </div>
      </Card>

      {h.rooms.map((room) => (
        <Card key={room.id} className="space-y-2">
          <h2 className="font-medium capitalize">{room.name}</h2>
          <div className="divide-y divide-ink-100">
            {room.devices.map((d) => (
              <div key={d.id} className="flex items-center justify-between py-2 text-sm">
                <span>{d.name}</span>
                <span className="text-ink-400">
                  {d.category.replace(/_/g, " ")} · {d.kwh_estimate} kWh/{d.estimate_period}
                </span>
              </div>
            ))}
          </div>
        </Card>
      ))}

      <Card className="space-y-4">
        <h2 className="font-medium">Generate a dataset from this household</h2>
        <div className="grid grid-cols-2 gap-4">
          <Field label="Start date">
            <Input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
          </Field>
          <Field label="Number of days">
            <Input
              type="number"
              min={5}
              max={1095}
              value={nDays}
              onChange={(e) => setNDays(parseInt(e.target.value || "0", 10))}
            />
          </Field>
        </div>
        <Field label={`Error / noise allowance: ±${errorPct}%`}>
          <input
            type="range"
            min={0}
            max={30}
            value={errorPct}
            onChange={(e) => setErrorPct(parseInt(e.target.value, 10))}
            className="w-full accent-volt-600"
          />
        </Field>
        {generate.isError && (
          <p className="text-sm text-red-600">{(generate.error as Error).message}</p>
        )}
        <Button onClick={() => generate.mutate()} loading={generate.isPending}>
          <Zap className="h-4 w-4" /> Generate dataset
        </Button>
      </Card>
    </div>
  );
}
