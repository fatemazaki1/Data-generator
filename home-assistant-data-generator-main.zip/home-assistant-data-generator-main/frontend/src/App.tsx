import type { ReactNode } from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import { Layout } from "./components/Layout";
import { Spinner } from "./components/ui";
import { useAuth } from "./lib/auth";
import { Dashboard } from "./pages/Dashboard";
import { HouseholdDetail } from "./pages/HouseholdDetail";
import { Login } from "./pages/Login";
import { RunStatus } from "./pages/RunStatus";
import { Wizard } from "./pages/Wizard";

function Protected({ children }: { children: ReactNode }) {
  const { username, ready } = useAuth();
  if (!ready) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Spinner />
      </div>
    );
  }
  if (!username) return <Navigate to="/login" replace />;
  return <Layout>{children}</Layout>;
}

export function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<Protected><Dashboard /></Protected>} />
      <Route path="/new" element={<Protected><Wizard /></Protected>} />
      <Route path="/households/:id" element={<Protected><HouseholdDetail /></Protected>} />
      <Route path="/runs/:id" element={<Protected><RunStatus /></Protected>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
