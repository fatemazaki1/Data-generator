export type EstimatePeriod = "day" | "week" | "month" | "year";

export interface CategoryInfo {
  category: string;
  archetype: string;
  label: string;
  default_kwh_per_day: number;
}

export interface RoomTypeInfo {
  room_type: string;
  default_categories: string[];
}

export interface LifestyleInfo {
  preset: string;
  label: string;
}

export interface Catalog {
  categories: CategoryInfo[];
  room_types: RoomTypeInfo[];
  lifestyles: LifestyleInfo[];
}

export interface DeviceInput {
  name: string;
  category: string;
  kwh_estimate: number;
  estimate_period: EstimatePeriod;
}

export interface RoomInput {
  name: string;
  room_type: string;
  devices: DeviceInput[];
}

export interface HouseholdInput {
  name: string;
  latitude: number;
  longitude: number;
  timezone: string;
  lifestyle: string;
  holidays_country: string;
  rooms: RoomInput[];
}

export interface HouseholdSummary {
  id: string;
  name: string;
  lifestyle: string;
  created_at: string;
}

export interface Household extends HouseholdInput {
  id: string;
  rooms: (RoomInput & { id: string; devices: (DeviceInput & { id: string })[] })[];
  created_at: string;
}

export interface Validation {
  ok: boolean;
  errors: string[];
  warnings: string[];
  stats: Record<string, number>;
}

export interface SimulationRun {
  id: string;
  status: "queued" | "running" | "completed" | "failed";
  phase: string;
  progress: number;
  n_days: number;
  seed: number;
  validation: Validation | null;
  error_message: string | null;
  created_at: string;
  updated_at: string;
}
