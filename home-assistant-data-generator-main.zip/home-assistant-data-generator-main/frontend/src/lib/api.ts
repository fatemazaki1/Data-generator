import type {
  Catalog,
  Household,
  HouseholdInput,
  HouseholdSummary,
  SimulationRun,
} from "./types";

const BASE = import.meta.env.VITE_API_BASE || "/api";

let accessToken: string | null = localStorage.getItem("access_token");
let refreshToken: string | null = localStorage.getItem("refresh_token");

export function setTokens(access: string | null, refresh: string | null) {
  accessToken = access;
  refreshToken = refresh;
  if (access) localStorage.setItem("access_token", access);
  else localStorage.removeItem("access_token");
  if (refresh) localStorage.setItem("refresh_token", refresh);
  else localStorage.removeItem("refresh_token");
}

export function getAccessToken() {
  return accessToken;
}

class ApiError extends Error {
  constructor(public status: number, public detail: string) {
    super(detail);
  }
}

async function refreshAccess(): Promise<boolean> {
  if (!refreshToken) return false;
  const res = await fetch(`${BASE}/auth/refresh`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ refresh_token: refreshToken }),
  });
  if (!res.ok) {
    setTokens(null, null);
    return false;
  }
  const data = await res.json();
  setTokens(data.access_token, data.refresh_token);
  return true;
}

async function request<T>(path: string, init: RequestInit = {}, retry = true): Promise<T> {
  const headers = new Headers(init.headers);
  if (accessToken) headers.set("Authorization", `Bearer ${accessToken}`);
  if (init.body && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }
  const res = await fetch(`${BASE}${path}`, { ...init, headers });

  if (res.status === 401 && retry && refreshToken) {
    if (await refreshAccess()) return request<T>(path, init, false);
  }
  if (!res.ok) {
    let detail = res.statusText;
    try {
      detail = (await res.json()).detail ?? detail;
    } catch {
      /* ignore */
    }
    throw new ApiError(res.status, detail);
  }
  if (res.status === 204) return undefined as T;
  return res.json();
}

export const api = {
  async login(username: string, password: string) {
    let res: Response;
    try {
      res = await fetch(`${BASE}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
    } catch {
      throw new ApiError(0, "Cannot reach the API server.");
    }
    if (res.status === 401) throw new ApiError(401, "Invalid username or password.");
    if (!res.ok) throw new ApiError(res.status, `Login failed (HTTP ${res.status}).`);
    const data = await res.json();
    setTokens(data.access_token, data.refresh_token);
    return data;
  },
  async logout() {
    if (refreshToken) {
      await fetch(`${BASE}/auth/logout`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ refresh_token: refreshToken }),
      }).catch(() => {});
    }
    setTokens(null, null);
  },
  me: () => request<{ user_id: string; username: string }>("/auth/me"),
  catalog: () => request<Catalog>("/catalog"),
  listHouseholds: () => request<HouseholdSummary[]>("/households"),
  getHousehold: (id: string) => request<Household>(`/households/${id}`),
  createHousehold: (body: HouseholdInput) =>
    request<Household>("/households", { method: "POST", body: JSON.stringify(body) }),
  deleteHousehold: (id: string) =>
    request<void>(`/households/${id}`, { method: "DELETE" }),
  listRuns: () => request<SimulationRun[]>("/simulations"),
  getRun: (id: string) => request<SimulationRun>(`/simulations/${id}`),
  deleteRun: (id: string) => request<void>(`/simulations/${id}`, { method: "DELETE" }),
  createRun: (body: {
    household_id: string;
    start_date: string;
    n_days: number;
    error_allowance_pct: number;
    seed?: number;
  }) => request<SimulationRun>("/simulations", { method: "POST", body: JSON.stringify(body) }),
  async download(id: string) {
    const headers = new Headers();
    if (accessToken) headers.set("Authorization", `Bearer ${accessToken}`);
    let res = await fetch(`${BASE}/simulations/${id}/download`, { headers });
    if (res.status === 401 && (await refreshAccess())) {
      headers.set("Authorization", `Bearer ${accessToken}`);
      res = await fetch(`${BASE}/simulations/${id}/download`, { headers });
    }
    if (!res.ok) throw new ApiError(res.status, "Download not ready");
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `ha-energy-dataset-${id}.zip`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  },
};

export { ApiError };
