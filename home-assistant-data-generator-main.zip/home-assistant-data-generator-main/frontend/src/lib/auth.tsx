import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { api, getAccessToken } from "./api";

interface AuthState {
  username: string | null;
  ready: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [username, setUsername] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    (async () => {
      if (getAccessToken()) {
        try {
          const me = await api.me();
          setUsername(me.username);
        } catch {
          /* token invalid */
        }
      }
      setReady(true);
    })();
  }, []);

  const login = async (u: string, p: string) => {
    await api.login(u, p);
    const me = await api.me();
    setUsername(me.username);
  };

  const logout = async () => {
    await api.logout();
    setUsername(null);
  };

  return (
    <AuthContext.Provider value={{ username, ready, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
