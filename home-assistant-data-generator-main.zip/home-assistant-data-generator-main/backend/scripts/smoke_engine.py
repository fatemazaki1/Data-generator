"""Standalone smoke test for the simulation engine (no DB/Redis/FastAPI)."""

from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.domain.catalog import DeviceCategory, EstimatePeriod, LifestylePreset, RoomType
from src.domain.exporters.csv import write_appliance_csvs, write_energy_history, write_weather
from src.domain.exporters.sqlite import write_sqlite
from src.domain.models import DeviceSpec, HouseholdSpec, SimulationConfig
from src.domain.simulator import simulate
from src.domain.validator import validate

devices = [
    DeviceSpec("d1", "Kitchen Fridge", DeviceCategory.REFRIGERATOR, RoomType.KITCHEN, 1.0),
    DeviceSpec("d2", "Heat Pump", DeviceCategory.HEAT_PUMP, RoomType.UTILITY, 8.0),
    DeviceSpec("d3", "Living Room Lights", DeviceCategory.LIGHTING, RoomType.LIVING_ROOM, 1.5),
    DeviceSpec("d4", "TV", DeviceCategory.TV, RoomType.LIVING_ROOM, 1.0),
    DeviceSpec("d5", "Dishwasher", DeviceCategory.DISHWASHER, RoomType.KITCHEN, 1.0),
    DeviceSpec("d6", "EV Charger", DeviceCategory.EV_CHARGER, RoomType.GARAGE, 8.0),
    DeviceSpec("d7", "Water Heater", DeviceCategory.WATER_HEATER, RoomType.BATHROOM, 4.0),
    DeviceSpec("d8", "Office PC", DeviceCategory.COMPUTER, RoomType.HOME_OFFICE, 1.2),
]
household = HouseholdSpec(
    latitude=47.0,
    longitude=8.0,
    timezone="Europe/Zurich",
    start_date=date(2024, 1, 1),
    n_days=180,
    lifestyle=LifestylePreset.FAMILY_WITH_KIDS,
    error_allowance_pct=10.0,
    holidays_country="CH",
    master_seed=42,
)
config = SimulationConfig(household=household, devices=tuple(devices))

result = simulate(config)
report = validate(result, has_thermostatic=True)

print("rows:", len(result.index))
print("meta:", result.meta)
print("validation ok:", report.ok)
print("errors:", report.errors)
print("warnings:", report.warnings)
print("stats:", report.stats)

# Reproducibility check.
result2 = simulate(config)
import numpy as np

print("reproducible:", np.array_equal(result.gross_kwh, result2.gross_kwh))

# Per-device calibration check (expected daily totals near estimates).
for sid, (name, arr) in result.per_device.items():
    print(f"  {name:22s} daily kWh ~ {arr.sum() / household.n_days:6.2f}")

out = Path("/tmp/ha-energy-sim/smoke")
out.mkdir(parents=True, exist_ok=True)
print("energy:", write_energy_history(result, out))
print("weather:", write_weather(result, out))
print("appliances:", len(write_appliance_csvs(result, out)))
print("sqlite:", write_sqlite(result, out))

# Verify SQLite backfill reconstruction matches gross.
import sqlite3

conn = sqlite3.connect(out / "home-assistant_v2.db")
rows = conn.execute(
    "SELECT s.sum FROM statistics s JOIN statistics_meta m ON s.metadata_id = m.id "
    "WHERE m.statistic_id = ? ORDER BY s.start_ts",
    (household.grid_sensor_id,),
).fetchall()
conn.close()
sums = np.array([r[0] for r in rows])
reconstructed = np.diff(sums, prepend=0.0)
print("backfill reconstructs gross:", np.allclose(reconstructed, result.gross_kwh, atol=1e-6))
