"""Ultimate fidelity check: train ha-energy-forecast's actual model on our
generated energy_history.csv + weather.csv and produce a 48h forecast.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

REPO = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(
    "/tmp/claude-1000/-home-mooazelsayed-Documents-GitHub-home-assistant-data-generator/"
    "0f0b6cc2-3a22-4bc4-bd27-1ce59a8128ee/scratchpad/ha-energy-forecast"
)
sys.path.insert(0, str(REPO / "apps"))

bundle = Path(sys.argv[1])
energy = pd.read_csv(bundle / "energy_history.csv")
energy["timestamp"] = pd.to_datetime(energy["timestamp"])
weather = pd.read_csv(bundle / "weather.csv")
weather["timestamp"] = pd.to_datetime(weather["timestamp"])

print(f"loaded {len(energy)} energy rows, {len(weather)} weather rows")

from energy_forecast.model import EnergyForecastModel  # noqa: E402

model = EnergyForecastModel(model_dir=Path("/tmp/ha-energy-sim/model"), timezone="Europe/Zurich")
model.train(energy_df=energy, weather_df=weather, outdoor_df=None, country="CH")

print("engine:", model.engine)
print("last_mae:", model.last_mae)
print("trained model file exists:", (Path("/tmp/ha-energy-sim/model") / "energy_model.pkl").exists())
print("RESULT: PASS — repo model trained on our synthetic data" if model.model is not None
      else "RESULT: FAIL")
