"""End-to-end API exercise: login -> household -> simulate -> poll -> download."""

from __future__ import annotations

import sys
import time
import zipfile
from pathlib import Path

import httpx

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8092"
OUT = Path("/tmp/ha-energy-sim/dl.zip")


def main() -> None:
    c = httpx.Client(base_url=BASE, timeout=60.0)

    tok = c.post("/auth/login", json={"username": "admin", "password": "admin123"}).json()
    headers = {"Authorization": f"Bearer {tok['access_token']}"}
    print("login OK")

    cat = c.get("/catalog", headers=headers).json()
    print(f"catalog: {len(cat['categories'])} categories, {len(cat['lifestyles'])} lifestyles")

    hh = c.post(
        "/households",
        headers=headers,
        json={
            "name": "Test Home",
            "latitude": 47.0,
            "longitude": 8.0,
            "timezone": "Europe/Zurich",
            "lifestyle": "family_with_kids",
            "holidays_country": "CH",
            "rooms": [
                {"name": "Kitchen", "room_type": "kitchen", "devices": [
                    {"name": "Fridge", "category": "refrigerator", "kwh_estimate": 1.0},
                    {"name": "Oven", "category": "oven", "kwh_estimate": 1.5},
                    {"name": "Dishwasher", "category": "dishwasher", "kwh_estimate": 1.0}]},
                {"name": "Utility", "room_type": "utility", "devices": [
                    {"name": "Heat Pump", "category": "heat_pump", "kwh_estimate": 8.0}]},
                {"name": "Garage", "room_type": "garage", "devices": [
                    {"name": "EV Charger", "category": "ev_charger", "kwh_estimate": 8.0}]},
            ],
        },
    )
    hh.raise_for_status()
    household = hh.json()
    print(f"household created: {household['id']} with {len(household['rooms'])} rooms")

    run = c.post(
        "/simulations",
        headers=headers,
        json={
            "household_id": household["id"],
            "start_date": "2024-01-01",
            "n_days": 120,
            "error_allowance_pct": 10,
            "seed": 42,
        },
    )
    run.raise_for_status()
    run_id = run.json()["id"]
    print(f"simulation queued: {run_id}")

    status = "queued"
    for _ in range(40):
        s = c.get(f"/simulations/{run_id}", headers=headers).json()
        status = s["status"]
        print(f"  status={status} phase={s['phase']} progress={s['progress']}")
        if status in ("completed", "failed"):
            if status == "completed":
                print("  validation:", s["validation"]["ok"],
                      "warnings:", s["validation"]["warnings"])
            else:
                print("  error:", s.get("error_message"), s.get("validation"))
            break
        time.sleep(1.0)

    assert status == "completed", f"run did not complete: {status}"

    resp = c.get(f"/simulations/{run_id}/download", headers=headers)
    resp.raise_for_status()
    OUT.write_bytes(resp.content)
    with zipfile.ZipFile(OUT) as z:
        names = z.namelist()
    print(f"downloaded zip ({OUT.stat().st_size} bytes):")
    for n in names:
        print("   ", n)
    print("RUN_ID", run_id)


if __name__ == "__main__":
    main()
