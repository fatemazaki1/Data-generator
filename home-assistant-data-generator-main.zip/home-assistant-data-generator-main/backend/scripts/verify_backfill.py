"""Decisive fidelity check: run ha-energy-forecast's EXACT backfill transform
against our generated home-assistant_v2.db and confirm it reproduces our
energy_history.csv (timestamps + gross_kwh).
"""

from __future__ import annotations

import sqlite3
import sys
from pathlib import Path

import pandas as pd

bundle_dir = Path(sys.argv[1])
db = bundle_dir / "home-assistant_v2.db"
csv = bundle_dir / "energy_history.csv"
ENTITY = "sensor.grid_import_energy"
TZ = "Europe/Zurich"
MAX_HOURLY_KWH = 50.0

# --- Replicate the repo's backfill transform verbatim --------------------------
con = sqlite3.connect(db)
rows = con.execute(
    """
    SELECT s.start_ts AS epoch, s.sum AS cumsum
    FROM statistics s
    JOIN statistics_meta sm ON s.metadata_id = sm.id
    WHERE sm.statistic_id = ?
    ORDER BY epoch
    """,
    (ENTITY,),
).fetchall()
con.close()

df = pd.DataFrame(rows, columns=["epoch", "cumsum"])
df["epoch"] = pd.to_numeric(df["epoch"])
df["cumsum"] = pd.to_numeric(df["cumsum"])
df["timestamp"] = (
    pd.to_datetime(df["epoch"], unit="s", utc=True).dt.tz_convert(TZ).dt.tz_localize(None)
)
df = df.sort_values("timestamp").reset_index(drop=True)
df["gross_kwh"] = df["cumsum"].diff().clip(lower=0)
df = df.dropna(subset=["gross_kwh"])
df = df[(df["gross_kwh"] > 0) & (df["gross_kwh"] < MAX_HOURLY_KWH)]
backfilled = df[["timestamp", "gross_kwh"]].reset_index(drop=True)

# --- Compare to our energy_history.csv ----------------------------------------
ours = pd.read_csv(csv)
ours["timestamp"] = pd.to_datetime(ours["timestamp"])
# Backfill drops the first row (diff → NaN); align on the overlap.
merged = ours.merge(backfilled, on="timestamp", suffixes=("_ours", "_backfill"))

print(f"our rows:        {len(ours)}")
print(f"backfilled rows: {len(backfilled)}")
print(f"matched timestamps: {len(merged)} (expect our_rows - 1 = {len(ours) - 1})")
diffs = (merged["gross_kwh_ours"] - merged["gross_kwh_backfill"]).abs()
# Up to 2 rows may differ at DST spring-forward/fall-back transitions, where a
# local hour legitimately does not exist / repeats — this matches real HA data.
n_diff = int((diffs > 1e-4).sum())
print(f"matched rows differing >1e-4: {n_diff} (DST transitions allowed)")
print(f"max gross_kwh difference on matched rows: {diffs.max():.8f}")
print(f"first aligned ts ours={ours['timestamp'].iloc[1]} backfill={backfilled['timestamp'].iloc[0]}")
ok = len(merged) >= len(ours) - 2 and n_diff <= 2
print("RESULT:", "PASS — backfill reconstructs our dataset" if ok else "FAIL")
sys.exit(0 if ok else 1)
