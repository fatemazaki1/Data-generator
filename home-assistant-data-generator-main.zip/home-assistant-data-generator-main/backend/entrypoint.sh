#!/usr/bin/env sh
set -eu

# Apply DB migrations (idempotent) before starting the API.
alembic upgrade head

exec "$@"
