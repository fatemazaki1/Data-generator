"""Unit tests for the simulation engine and validator."""

from __future__ import annotations

from datetime import date

import numpy as np
import pytest

from src.domain.catalog import DeviceCategory, LifestylePreset, RoomType
from src.domain.models import DeviceSpec, HouseholdSpec, SimulationConfig
from src.domain.simulator import MAX_HOURLY_KWH, simulate
from src.domain.validator import validate


def _config(seed: int = 1, n_days: int = 90) -> SimulationConfig:
    devices = (
        DeviceSpec("d1", "Fridge", DeviceCategory.REFRIGERATOR, RoomType.KITCHEN, 1.0),
        DeviceSpec("d2", "Heat Pump", DeviceCategory.HEAT_PUMP, RoomType.UTILITY, 8.0),
        DeviceSpec("d3", "Lights", DeviceCategory.LIGHTING, RoomType.LIVING_ROOM, 1.5),
        DeviceSpec("d4", "Dishwasher", DeviceCategory.DISHWASHER, RoomType.KITCHEN, 1.0),
        DeviceSpec("d5", "EV", DeviceCategory.EV_CHARGER, RoomType.GARAGE, 8.0),
    )
    household = HouseholdSpec(
        latitude=47.0, longitude=8.0, timezone="Europe/Zurich",
        start_date=date(2024, 1, 1), n_days=n_days,
        lifestyle=LifestylePreset.FAMILY_WITH_KIDS, master_seed=seed,
    )
    return SimulationConfig(household=household, devices=devices)


def test_output_shape_and_bounds() -> None:
    result = simulate(_config())
    assert len(result.index) == 90 * 24
    assert np.all(result.gross_kwh > 0)
    assert np.all(result.gross_kwh <= MAX_HOURLY_KWH)
    assert not np.any(np.isnan(result.gross_kwh))


def test_reproducible_with_same_seed() -> None:
    a = simulate(_config(seed=7))
    b = simulate(_config(seed=7))
    assert np.array_equal(a.gross_kwh, b.gross_kwh)


def test_different_seed_differs() -> None:
    a = simulate(_config(seed=1))
    b = simulate(_config(seed=2))
    assert not np.array_equal(a.gross_kwh, b.gross_kwh)


def test_device_calibration_matches_estimate() -> None:
    config = _config()
    result = simulate(config)
    for device in config.devices:
        _, series = result.per_device[device.statistic_id]
        daily = series.sum() / config.n_days
        assert device.kwh_per_day * 0.8 <= daily <= device.kwh_per_day * 1.2


def test_cumulative_reconstructs_gross() -> None:
    result = simulate(_config())
    reconstructed = np.diff(result.cumulative_kwh, prepend=0.0)
    assert np.allclose(reconstructed, result.gross_kwh, atol=1e-6)


def test_validator_passes_for_valid_data() -> None:
    result = simulate(_config(n_days=120))
    report = validate(result, has_thermostatic=True)
    assert report.ok, report.errors


def test_validator_catches_too_few_rows() -> None:
    with pytest.raises(Exception):
        simulate(_config(n_days=2))


def test_weekday_weekend_differ() -> None:
    result = simulate(_config(n_days=120))
    dow = result.index.dayofweek.to_numpy()
    weekday = result.gross_kwh[dow < 5].mean()
    weekend = result.gross_kwh[dow >= 5].mean()
    # Family lifestyle should produce a measurable weekday/weekend difference.
    assert abs(weekday - weekend) > 0
