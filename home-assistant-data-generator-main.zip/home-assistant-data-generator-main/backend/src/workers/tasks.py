"""Background generation worker.

A single in-process async manager runs generation jobs off the request path.
Progress is published live to Redis (read back by the status endpoint); the
durable run record lives in Postgres. Because the engine is deterministic from
the stored snapshot, interrupted jobs are simply re-scheduled on startup.
"""

from __future__ import annotations

import asyncio
import logging
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from src.domain.errors import SimulationValidationError
from src.models.db import SimulationRunRow
from src.pipelines.simulation_pipeline import SimulationPipeline

logger = logging.getLogger(__name__)


class JobManager:
    def __init__(
        self,
        sessionmaker: async_sessionmaker[AsyncSession],
        pipeline: SimulationPipeline,
    ) -> None:
        self._sessionmaker = sessionmaker
        self._pipeline = pipeline
        self._tasks: set[asyncio.Task] = set()

    def schedule(self, run_id: UUID) -> None:
        task = asyncio.create_task(self._execute(run_id))
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    async def resume_pending(self) -> None:
        async with self._sessionmaker() as session:
            result = await session.execute(
                select(SimulationRunRow.id).where(
                    SimulationRunRow.status.in_(["queued", "running"])
                )
            )
            run_ids = [row[0] for row in result.all()]
        for run_id in run_ids:
            logger.info("Resuming interrupted simulation run %s", run_id)
            self.schedule(run_id)

    async def shutdown(self) -> None:
        for task in list(self._tasks):
            task.cancel()
        await asyncio.gather(*self._tasks, return_exceptions=True)

    async def _execute(self, run_id: UUID) -> None:
        async with self._sessionmaker() as session:
            run = await session.get(SimulationRunRow, run_id)
            if run is None:
                return
            run.status = "running"
            run.phase = "weather"
            run.progress = 5
            config_json = run.config_json
            await session.commit()

        try:
            zip_path, report = await self._pipeline.run(run_id, config_json)
        except SimulationValidationError as exc:
            await self._fail(run_id, str(exc), problems=exc.problems)
            return
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            logger.exception("Simulation run %s failed", run_id)
            await self._fail(run_id, f"{type(exc).__name__}: {exc}")
            return

        validation = {
            "ok": report.ok,
            "errors": report.errors,
            "warnings": report.warnings,
            "stats": report.stats,
        }
        if not report.ok:
            await self._fail(run_id, "Generated dataset failed validation", validation=validation)
            return

        async with self._sessionmaker() as session:
            run = await session.get(SimulationRunRow, run_id)
            if run is None:
                return
            run.status = "completed"
            run.phase = "completed"
            run.progress = 100
            run.artifact_path = str(zip_path)
            run.validation_json = validation
            run.error_message = None
            await session.commit()

    async def _fail(
        self,
        run_id: UUID,
        message: str,
        problems: list[str] | None = None,
        validation: dict | None = None,
    ) -> None:
        async with self._sessionmaker() as session:
            run = await session.get(SimulationRunRow, run_id)
            if run is None:
                return
            run.status = "failed"
            run.phase = "failed"
            run.error_message = message
            if validation is not None:
                run.validation_json = validation
            elif problems is not None:
                run.validation_json = {
                    "ok": False,
                    "errors": problems,
                    "warnings": [],
                    "stats": {},
                }
            await session.commit()
