"""Open-Meteo archive weather fetcher with on-disk caching.

Mirrors the data source ha-energy-forecast itself uses, so simulated weather is
maximally realistic. Falls back to ``None`` on any failure; the simulator then
generates a synthetic series. Cached by (lat, lon, date-range) for offline replay
and reproducibility.
"""

from __future__ import annotations

import hashlib
import logging
from datetime import date, timedelta
from pathlib import Path

import httpx
import pandas as pd

from src.domain.weather import WEATHER_COLUMNS

logger = logging.getLogger(__name__)

_ARCHIVE_URL = "https://archive-api.open-meteo.com/v1/archive"
_HOURLY_VARS = [
    "temperature_2m",
    "precipitation",
    "sunshine_duration",
    "wind_speed_10m",
    "cloud_cover",
    "direct_radiation",
    "relative_humidity_2m",
]


class WeatherCache:
    def __init__(self, cache_dir: str, enabled: bool = True) -> None:
        self._dir = Path(cache_dir)
        self._dir.mkdir(parents=True, exist_ok=True)
        self._enabled = enabled

    def _key(self, latitude: float, longitude: float, start: date, end: date) -> Path:
        raw = f"{latitude:.3f}:{longitude:.3f}:{start.isoformat()}:{end.isoformat()}"
        digest = hashlib.sha256(raw.encode()).hexdigest()[:16]
        return self._dir / f"weather_{digest}.parquet"

    async def fetch(
        self, latitude: float, longitude: float, start: date, n_days: int
    ) -> pd.DataFrame | None:
        if not self._enabled:
            return None
        end = start + timedelta(days=n_days - 1)
        cache_path = self._key(latitude, longitude, start, end)
        if cache_path.exists():
            try:
                return pd.read_parquet(cache_path)
            except Exception:  # noqa: BLE001
                cache_path.unlink(missing_ok=True)

        try:
            frame = await self._request(latitude, longitude, start, end)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Open-Meteo fetch failed (%s); using synthetic weather", exc)
            return None

        try:
            frame.to_parquet(cache_path)
        except Exception:  # noqa: BLE001
            pass
        return frame

    async def _request(
        self, latitude: float, longitude: float, start: date, end: date
    ) -> pd.DataFrame:
        params = {
            "latitude": latitude,
            "longitude": longitude,
            "start_date": start.isoformat(),
            "end_date": end.isoformat(),
            "hourly": ",".join(_HOURLY_VARS),
            "timezone": "auto",
        }
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(_ARCHIVE_URL, params=params)
            response.raise_for_status()
            data = response.json()
        hourly = data["hourly"]
        index = pd.to_datetime(hourly["time"])
        frame = pd.DataFrame(
            {
                "temp_c": hourly["temperature_2m"],
                "precipitation_mm": hourly["precipitation"],
                # Open-Meteo gives sunshine in seconds/hour → minutes.
                "sunshine_min": [v / 60.0 if v is not None else 0.0
                                 for v in hourly["sunshine_duration"]],
                "wind_kmh": hourly["wind_speed_10m"],
                "cloud_cover_pct": hourly["cloud_cover"],
                "direct_radiation_wm2": hourly["direct_radiation"],
                "humidity": hourly["relative_humidity_2m"],
            },
            index=index,
        )
        return frame[WEATHER_COLUMNS].ffill().bfill().fillna(0.0)
