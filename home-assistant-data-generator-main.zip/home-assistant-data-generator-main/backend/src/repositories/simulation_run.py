from __future__ import annotations

from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.models.db import SimulationRunRow


class SimulationRunRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def create(
        self,
        owner_user_id: UUID,
        household_id: UUID,
        n_days: int,
        seed: int,
        config_json: dict,
    ) -> SimulationRunRow:
        row = SimulationRunRow(
            owner_user_id=owner_user_id,
            household_id=household_id,
            status="queued",
            phase="queued",
            progress=0,
            n_days=n_days,
            seed=seed,
            config_json=config_json,
        )
        self._session.add(row)
        await self._session.flush()
        await self._session.refresh(row)
        return row

    async def get(self, run_id: UUID, owner_user_id: UUID) -> SimulationRunRow | None:
        result = await self._session.execute(
            select(SimulationRunRow).where(
                SimulationRunRow.id == run_id,
                SimulationRunRow.owner_user_id == owner_user_id,
            )
        )
        return result.scalar_one_or_none()

    async def get_any(self, run_id: UUID) -> SimulationRunRow | None:
        return await self._session.get(SimulationRunRow, run_id)

    async def delete(self, run: SimulationRunRow) -> None:
        await self._session.delete(run)
        await self._session.flush()

    async def list_for_owner(self, owner_user_id: UUID) -> list[SimulationRunRow]:
        result = await self._session.execute(
            select(SimulationRunRow)
            .where(SimulationRunRow.owner_user_id == owner_user_id)
            .order_by(SimulationRunRow.created_at.desc())
        )
        return list(result.scalars().all())
