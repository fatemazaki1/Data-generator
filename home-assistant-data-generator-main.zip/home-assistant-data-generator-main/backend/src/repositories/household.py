from __future__ import annotations

from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.models.api import HouseholdCreate, HouseholdUpdate
from src.models.db import DeviceRow, HouseholdRow, RoomRow


class HouseholdRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def create(self, owner_user_id: UUID, body: HouseholdCreate) -> HouseholdRow:
        household = HouseholdRow(
            owner_user_id=owner_user_id,
            name=body.name,
            latitude=body.latitude,
            longitude=body.longitude,
            timezone=body.timezone,
            lifestyle=body.lifestyle.value,
            holidays_country=body.holidays_country,
        )
        for room in body.rooms:
            room_row = RoomRow(name=room.name, room_type=room.room_type.value)
            for device in room.devices:
                room_row.devices.append(
                    DeviceRow(
                        name=device.name,
                        category=device.category.value,
                        kwh_estimate=device.kwh_estimate,
                        estimate_period=device.estimate_period.value,
                    )
                )
            household.rooms.append(room_row)
        self._session.add(household)
        await self._session.flush()
        # Re-fetch through a query so the selectin relationships (rooms/devices)
        # are eagerly materialised before sync serialisation.
        return await self._get_loaded(household.id)

    async def _get_loaded(self, household_id: UUID) -> HouseholdRow:
        result = await self._session.execute(
            select(HouseholdRow).where(HouseholdRow.id == household_id)
        )
        return result.scalar_one()

    async def get(self, household_id: UUID, owner_user_id: UUID) -> HouseholdRow | None:
        result = await self._session.execute(
            select(HouseholdRow).where(
                HouseholdRow.id == household_id,
                HouseholdRow.owner_user_id == owner_user_id,
            )
        )
        return result.scalar_one_or_none()

    async def list_for_owner(self, owner_user_id: UUID) -> list[HouseholdRow]:
        result = await self._session.execute(
            select(HouseholdRow)
            .where(HouseholdRow.owner_user_id == owner_user_id)
            .order_by(HouseholdRow.created_at.desc())
        )
        return list(result.scalars().all())

    async def update(self, household: HouseholdRow, body: HouseholdUpdate) -> HouseholdRow:
        if body.name is not None:
            household.name = body.name
        if body.latitude is not None:
            household.latitude = body.latitude
        if body.longitude is not None:
            household.longitude = body.longitude
        if body.timezone is not None:
            household.timezone = body.timezone
        if body.lifestyle is not None:
            household.lifestyle = body.lifestyle.value
        if body.holidays_country is not None:
            household.holidays_country = body.holidays_country
        await self._session.flush()
        return household

    async def delete(self, household: HouseholdRow) -> None:
        await self._session.delete(household)
        await self._session.flush()
