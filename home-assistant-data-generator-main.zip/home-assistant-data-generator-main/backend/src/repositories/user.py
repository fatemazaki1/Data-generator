from __future__ import annotations

from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.models.db import UserRow


class UserRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def get_by_username(self, username: str) -> UserRow | None:
        result = await self._session.execute(
            select(UserRow).where(UserRow.username == username)
        )
        return result.scalar_one_or_none()

    async def get(self, user_id: UUID) -> UserRow | None:
        return await self._session.get(UserRow, user_id)

    async def create(self, username: str, password_hash: str) -> UserRow:
        row = UserRow(username=username, password_hash=password_hash)
        self._session.add(row)
        await self._session.flush()
        return row
