from __future__ import annotations

import json
import logging
import logging.config
from pathlib import Path
from typing import cast

import sentry_sdk
import yaml
from fastapi import FastAPI

from src.config import Settings
from src.infra.db import setup_database
from src.infra.redis_client import setup_redis
from src.infra.security import hash_password
from src.pipelines.simulation_pipeline import SimulationPipeline
from src.repositories.user import UserRepository
from src.repositories.weather_cache import WeatherCache
from src.workers.tasks import JobManager

logger = logging.getLogger(__name__)


def setup_logging() -> None:
    with (Path(__file__).parent.parent / "logging.json").open() as handle:
        config = cast(dict, json.load(handle))
    logging.config.dictConfig(config)


def setup_settings() -> Settings:
    with (Path(__file__).parent.parent / "settings.yaml").open() as handle:
        return Settings.model_validate(yaml.safe_load(handle))


def setup_sentry(settings: Settings) -> None:
    if settings.sentry.dsn:
        sentry_sdk.init(
            server_name=settings.app.name,
            dsn=settings.sentry.dsn,
            environment=settings.sentry.environment,
        )


async def seed_admin(app: FastAPI) -> None:
    settings: Settings = app.state.settings
    sessionmaker = app.state.db_sessionmaker
    async with sessionmaker() as session:
        users = UserRepository(session)
        existing = await users.get_by_username(settings.auth.admin_username)
        if existing is None:
            await users.create(
                settings.auth.admin_username,
                hash_password(settings.auth.admin_password),
            )
            await session.commit()
            logger.info("Seeded admin user '%s'", settings.auth.admin_username)


async def setup_service(app: FastAPI) -> None:
    setup_logging()
    settings = setup_settings()
    setup_sentry(settings)
    db_engine, db_sessionmaker = setup_database(settings)
    redis = await setup_redis(settings)

    weather_cache = WeatherCache(settings.sim.weather_cache_dir, settings.sim.openmeteo_enabled)
    pipeline = SimulationPipeline(redis, weather_cache, settings.sim.artifact_dir)
    job_manager = JobManager(db_sessionmaker, pipeline)

    app.state.settings = settings
    app.state.db_engine = db_engine
    app.state.db_sessionmaker = db_sessionmaker
    app.state.redis = redis
    app.state.weather_cache = weather_cache
    app.state.simulation_pipeline = pipeline
    app.state.job_manager = job_manager

    await seed_admin(app)
    await job_manager.resume_pending()
