from __future__ import annotations

from fastapi import FastAPI, Request, status
from fastapi.responses import JSONResponse

from src.domain.errors import (
    AuthTokenError,
    DeviceNotFoundError,
    DomainError,
    HouseholdNotFoundError,
    InvalidCredentialsError,
    InvalidSimulationConfigError,
    RoomNotFoundError,
    SimulationNotReadyError,
    SimulationRunNotFoundError,
    SimulationValidationError,
)
from src.models.api import ErrorResponse


def register_exception_handlers(app: FastAPI) -> None:
    @app.exception_handler(InvalidCredentialsError)
    async def invalid_credentials_handler(
        request: Request, exc: InvalidCredentialsError
    ) -> JSONResponse:
        return _json(status.HTTP_401_UNAUTHORIZED, "Invalid username or password")

    @app.exception_handler(AuthTokenError)
    async def auth_token_handler(request: Request, exc: AuthTokenError) -> JSONResponse:
        return _json(status.HTTP_401_UNAUTHORIZED, str(exc))

    @app.exception_handler(HouseholdNotFoundError)
    async def household_not_found_handler(
        request: Request, exc: HouseholdNotFoundError
    ) -> JSONResponse:
        return _json(status.HTTP_404_NOT_FOUND, "Household not found")

    @app.exception_handler(RoomNotFoundError)
    async def room_not_found_handler(request: Request, exc: RoomNotFoundError) -> JSONResponse:
        return _json(status.HTTP_404_NOT_FOUND, "Room not found")

    @app.exception_handler(DeviceNotFoundError)
    async def device_not_found_handler(request: Request, exc: DeviceNotFoundError) -> JSONResponse:
        return _json(status.HTTP_404_NOT_FOUND, "Device not found")

    @app.exception_handler(SimulationRunNotFoundError)
    async def run_not_found_handler(
        request: Request, exc: SimulationRunNotFoundError
    ) -> JSONResponse:
        return _json(status.HTTP_404_NOT_FOUND, "Simulation run not found")

    @app.exception_handler(SimulationNotReadyError)
    async def run_not_ready_handler(
        request: Request, exc: SimulationNotReadyError
    ) -> JSONResponse:
        return _json(status.HTTP_409_CONFLICT, str(exc))

    @app.exception_handler(InvalidSimulationConfigError)
    async def invalid_config_handler(
        request: Request, exc: InvalidSimulationConfigError
    ) -> JSONResponse:
        return _json(status.HTTP_400_BAD_REQUEST, str(exc))

    @app.exception_handler(SimulationValidationError)
    async def validation_handler(
        request: Request, exc: SimulationValidationError
    ) -> JSONResponse:
        return _json(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc))

    @app.exception_handler(DomainError)
    async def domain_handler(request: Request, exc: DomainError) -> JSONResponse:
        return _json(status.HTTP_400_BAD_REQUEST, str(exc))


def _json(status_code: int, detail: str) -> JSONResponse:
    return JSONResponse(status_code=status_code, content=ErrorResponse(detail=detail).model_dump())
