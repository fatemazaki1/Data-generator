from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.dependencies import AUTH_PIPELINE_DEP, CURRENT_USER_DEP, DB_SESSION_DEP
from src.domain.errors import AuthTokenError
from src.models.api import (
    LoginRequest,
    MeResponse,
    RefreshRequest,
    TokenResponse,
)
from src.pipelines.auth import AuthPipeline
from src.repositories.user import UserRepository

router = APIRouter(prefix="/auth")


@router.post("/login")
async def login(body: LoginRequest, auth: AuthPipeline = AUTH_PIPELINE_DEP) -> TokenResponse:
    return await auth.login(body.username, body.password)


@router.post("/refresh")
async def refresh(body: RefreshRequest, auth: AuthPipeline = AUTH_PIPELINE_DEP) -> TokenResponse:
    return await auth.refresh(body.refresh_token)


@router.post("/logout", status_code=204)
async def logout(body: RefreshRequest, auth: AuthPipeline = AUTH_PIPELINE_DEP) -> None:
    await auth.logout(body.refresh_token)


@router.get("/me")
async def me(
    user_id: UUID = CURRENT_USER_DEP,
    session: AsyncSession = DB_SESSION_DEP,
) -> MeResponse:
    user = await UserRepository(session).get(user_id)
    if user is None:
        raise AuthTokenError("User no longer exists")
    return MeResponse(user_id=user.id, username=user.username)
