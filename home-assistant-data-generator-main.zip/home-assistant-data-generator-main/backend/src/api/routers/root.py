from __future__ import annotations

from fastapi import APIRouter, Response, status
from redis.asyncio import Redis
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.dependencies import DB_SESSION_DEP, REDIS_DEP, SETTINGS_DEP
from src.config import Settings
from src.models.api import ComponentStatus, HealthResponse, ReadinessResponse

router = APIRouter()


@router.get("/")
@router.get("/health")
@router.get("/healthz")
@router.get("/liveness")
async def health(settings: Settings = SETTINGS_DEP) -> HealthResponse:
    return HealthResponse(status="ok", service=settings.app.name)


@router.get("/readyz")
@router.get("/readiness")
async def readiness(
    response: Response,
    settings: Settings = SETTINGS_DEP,
    db: AsyncSession = DB_SESSION_DEP,
    redis: Redis = REDIS_DEP,
) -> ReadinessResponse:
    database = await _check_database(db)
    redis_status = await _check_redis(redis)
    ready = database.ok and redis_status.ok
    if not ready:
        response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
    return ReadinessResponse(
        status="ready" if ready else "not_ready",
        service=settings.app.name,
        database=database,
        redis=redis_status,
    )


async def _check_database(db: AsyncSession) -> ComponentStatus:
    try:
        await db.execute(text("select 1"))
        return ComponentStatus(ok=True)
    except Exception as exc:  # noqa: BLE001
        return ComponentStatus(ok=False, detail=exc.__class__.__name__)


async def _check_redis(redis: Redis) -> ComponentStatus:
    try:
        await redis.ping()
        return ComponentStatus(ok=True)
    except Exception as exc:  # noqa: BLE001
        return ComponentStatus(ok=False, detail=exc.__class__.__name__)
