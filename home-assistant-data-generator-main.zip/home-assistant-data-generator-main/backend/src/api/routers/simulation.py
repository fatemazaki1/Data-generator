from __future__ import annotations

import secrets
from pathlib import Path
from uuid import UUID

from fastapi import APIRouter, status
from fastapi.responses import FileResponse
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.dependencies import (
    CURRENT_USER_DEP,
    DB_SESSION_DEP,
    HOUSEHOLD_REPO_DEP,
    JOB_MANAGER_DEP,
    RUN_REPO_DEP,
    SIM_PIPELINE_DEP,
)
from src.domain.catalog import DeviceCategory, EstimatePeriod, LifestylePreset, RoomType
from src.domain.errors import (
    HouseholdNotFoundError,
    InvalidSimulationConfigError,
    SimulationNotReadyError,
    SimulationRunNotFoundError,
)
from src.domain.models import AwayPeriod, DeviceSpec, HouseholdSpec, SimulationConfig
from src.models.api import (
    SimulationCreateRequest,
    SimulationRunOut,
    ValidationOut,
)
from src.models.db import HouseholdRow, SimulationRunRow
from src.pipelines.simulation_pipeline import SimulationPipeline, config_to_dict
from src.repositories.household import HouseholdRepository
from src.repositories.simulation_run import SimulationRunRepository
from src.workers.tasks import JobManager

router = APIRouter(prefix="/simulations")


def _build_config(
    household: HouseholdRow, body: SimulationCreateRequest, seed: int
) -> SimulationConfig:
    devices: list[DeviceSpec] = []
    for room in household.rooms:
        for device in room.devices:
            devices.append(
                DeviceSpec(
                    device_id=str(device.id),
                    name=device.name,
                    category=DeviceCategory(device.category),
                    room_type=RoomType(room.room_type),
                    kwh_estimate=device.kwh_estimate,
                    estimate_period=EstimatePeriod(device.estimate_period),
                )
            )
    if not devices:
        raise InvalidSimulationConfigError(
            "Household has no devices; add at least one device before generating."
        )
    spec = HouseholdSpec(
        latitude=household.latitude,
        longitude=household.longitude,
        timezone=household.timezone,
        start_date=body.start_date,
        n_days=body.n_days,
        lifestyle=LifestylePreset(household.lifestyle),
        error_allowance_pct=body.error_allowance_pct,
        holidays_country=household.holidays_country,
        master_seed=seed,
        away_periods=tuple(AwayPeriod(p.start, p.end) for p in body.away_periods),
    )
    return SimulationConfig(household=spec, devices=tuple(devices))


def _to_out(row: SimulationRunRow, live: dict | None = None) -> SimulationRunOut:
    validation = ValidationOut(**row.validation_json) if row.validation_json else None
    phase = row.phase
    progress = row.progress
    if row.status == "running" and live:
        phase = live.get("phase", phase)
        progress = live.get("progress", progress)
    return SimulationRunOut(
        id=row.id,
        status=row.status,
        phase=phase,
        progress=progress,
        n_days=row.n_days,
        seed=row.seed,
        validation=validation,
        error_message=row.error_message,
        created_at=row.created_at,
        updated_at=row.updated_at,
    )


@router.post("", status_code=status.HTTP_202_ACCEPTED)
async def create_simulation(
    body: SimulationCreateRequest,
    user_id: UUID = CURRENT_USER_DEP,
    session: AsyncSession = DB_SESSION_DEP,
    households: HouseholdRepository = HOUSEHOLD_REPO_DEP,
    runs: SimulationRunRepository = RUN_REPO_DEP,
    jobs: JobManager = JOB_MANAGER_DEP,
) -> SimulationRunOut:
    household = await households.get(body.household_id, user_id)
    if household is None:
        raise HouseholdNotFoundError(body.household_id)

    seed = body.seed if body.seed is not None else secrets.randbelow(2**31)
    config = _build_config(household, body, seed)
    config_json = config_to_dict(config)

    run = await runs.create(
        owner_user_id=user_id,
        household_id=household.id,
        n_days=body.n_days,
        seed=seed,
        config_json=config_json,
    )
    # Commit before scheduling so the worker's own session can read the row.
    await session.commit()
    jobs.schedule(run.id)
    return _to_out(run)


@router.get("")
async def list_simulations(
    user_id: UUID = CURRENT_USER_DEP,
    runs: SimulationRunRepository = RUN_REPO_DEP,
) -> list[SimulationRunOut]:
    rows = await runs.list_for_owner(user_id)
    return [_to_out(row) for row in rows]


@router.get("/{run_id}")
async def get_simulation(
    run_id: UUID,
    user_id: UUID = CURRENT_USER_DEP,
    runs: SimulationRunRepository = RUN_REPO_DEP,
    pipeline: SimulationPipeline = SIM_PIPELINE_DEP,
) -> SimulationRunOut:
    row = await runs.get(run_id, user_id)
    if row is None:
        raise SimulationRunNotFoundError(run_id)
    live = await pipeline.get_progress(run_id) if row.status == "running" else None
    return _to_out(row, live)


@router.delete("/{run_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_simulation(
    run_id: UUID,
    user_id: UUID = CURRENT_USER_DEP,
    runs: SimulationRunRepository = RUN_REPO_DEP,
    pipeline: SimulationPipeline = SIM_PIPELINE_DEP,
) -> None:
    row = await runs.get(run_id, user_id)
    if row is None:
        raise SimulationRunNotFoundError(run_id)
    await pipeline.delete_artifacts(run_id)
    await runs.delete(row)


@router.get("/{run_id}/download")
async def download_simulation(
    run_id: UUID,
    user_id: UUID = CURRENT_USER_DEP,
    runs: SimulationRunRepository = RUN_REPO_DEP,
) -> FileResponse:
    row = await runs.get(run_id, user_id)
    if row is None:
        raise SimulationRunNotFoundError(run_id)
    if row.status != "completed" or not row.artifact_path:
        raise SimulationNotReadyError(run_id, row.status)
    path = Path(row.artifact_path)
    if not path.exists():
        raise SimulationNotReadyError(run_id, "artifact_missing")
    return FileResponse(
        path,
        media_type="application/zip",
        filename=f"ha-energy-dataset-{run_id}.zip",
    )
