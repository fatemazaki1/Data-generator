from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, status

from src.api.dependencies import CURRENT_USER_DEP, HOUSEHOLD_REPO_DEP
from src.domain.errors import HouseholdNotFoundError
from src.models.api import (
    HouseholdCreate,
    HouseholdOut,
    HouseholdSummary,
    HouseholdUpdate,
)
from src.repositories.household import HouseholdRepository

router = APIRouter(prefix="/households")


@router.post("", status_code=status.HTTP_201_CREATED)
async def create_household(
    body: HouseholdCreate,
    user_id: UUID = CURRENT_USER_DEP,
    repo: HouseholdRepository = HOUSEHOLD_REPO_DEP,
) -> HouseholdOut:
    household = await repo.create(user_id, body)
    return HouseholdOut.model_validate(household)


@router.get("")
async def list_households(
    user_id: UUID = CURRENT_USER_DEP,
    repo: HouseholdRepository = HOUSEHOLD_REPO_DEP,
) -> list[HouseholdSummary]:
    rows = await repo.list_for_owner(user_id)
    return [HouseholdSummary.model_validate(row) for row in rows]


@router.get("/{household_id}")
async def get_household(
    household_id: UUID,
    user_id: UUID = CURRENT_USER_DEP,
    repo: HouseholdRepository = HOUSEHOLD_REPO_DEP,
) -> HouseholdOut:
    household = await repo.get(household_id, user_id)
    if household is None:
        raise HouseholdNotFoundError(household_id)
    return HouseholdOut.model_validate(household)


@router.patch("/{household_id}")
async def update_household(
    household_id: UUID,
    body: HouseholdUpdate,
    user_id: UUID = CURRENT_USER_DEP,
    repo: HouseholdRepository = HOUSEHOLD_REPO_DEP,
) -> HouseholdOut:
    household = await repo.get(household_id, user_id)
    if household is None:
        raise HouseholdNotFoundError(household_id)
    household = await repo.update(household, body)
    return HouseholdOut.model_validate(household)


@router.delete("/{household_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_household(
    household_id: UUID,
    user_id: UUID = CURRENT_USER_DEP,
    repo: HouseholdRepository = HOUSEHOLD_REPO_DEP,
) -> None:
    household = await repo.get(household_id, user_id)
    if household is None:
        raise HouseholdNotFoundError(household_id)
    await repo.delete(household)
