from __future__ import annotations

from fastapi import APIRouter

from src.api.dependencies import CURRENT_USER_DEP
from src.domain.catalog import (
    CATEGORY_SPECS,
    LIFESTYLE_SPECS,
    ROOM_DEFAULT_DEVICES,
    RoomType,
)
from src.models.api import (
    CatalogResponse,
    CategoryInfo,
    LifestyleInfo,
    RoomTypeInfo,
)

router = APIRouter(prefix="/catalog")


@router.get("", dependencies=[CURRENT_USER_DEP])
async def get_catalog() -> CatalogResponse:
    categories = [
        CategoryInfo(
            category=spec.category,
            archetype=spec.archetype.value,
            label=spec.label,
            default_kwh_per_day=spec.default_kwh_per_day,
        )
        for spec in CATEGORY_SPECS.values()
    ]
    room_types = [
        RoomTypeInfo(room_type=rt, default_categories=ROOM_DEFAULT_DEVICES.get(rt, []))
        for rt in RoomType
    ]
    lifestyles = [
        LifestyleInfo(preset=spec.preset, label=spec.label)
        for spec in LIFESTYLE_SPECS.values()
    ]
    return CatalogResponse(categories=categories, room_types=room_types, lifestyles=lifestyles)
