from __future__ import annotations

from collections.abc import AsyncGenerator
from typing import cast
from uuid import UUID

from fastapi import Depends, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from redis.asyncio import Redis
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from src.config import Settings
from src.domain.errors import AuthTokenError
from src.pipelines.auth import AuthPipeline
from src.pipelines.simulation_pipeline import SimulationPipeline
from src.repositories.household import HouseholdRepository
from src.repositories.simulation_run import SimulationRunRepository
from src.repositories.user import UserRepository
from src.workers.tasks import JobManager


def get_settings(request: Request) -> Settings:
    return cast(Settings, request.app.state.settings)


def get_db_sessionmaker(request: Request) -> async_sessionmaker[AsyncSession]:
    return cast(async_sessionmaker[AsyncSession], request.app.state.db_sessionmaker)


DB_SESSIONMAKER_DEP = Depends(get_db_sessionmaker)


async def get_db_session(
    sessionmaker: async_sessionmaker[AsyncSession] = DB_SESSIONMAKER_DEP,
) -> AsyncGenerator[AsyncSession, None]:
    async with sessionmaker() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


def get_redis(request: Request) -> Redis:
    return cast(Redis, request.app.state.redis)


def get_job_manager(request: Request) -> JobManager:
    return cast(JobManager, request.app.state.job_manager)


def get_simulation_pipeline(request: Request) -> SimulationPipeline:
    return cast(SimulationPipeline, request.app.state.simulation_pipeline)


SETTINGS_DEP = Depends(get_settings)
DB_SESSION_DEP = Depends(get_db_session)
REDIS_DEP = Depends(get_redis)
JOB_MANAGER_DEP = Depends(get_job_manager)
SIM_PIPELINE_DEP = Depends(get_simulation_pipeline)

_bearer = HTTPBearer(auto_error=False)
BEARER_DEP = Depends(_bearer)


def get_auth_pipeline(
    redis: Redis = REDIS_DEP,
    session: AsyncSession = DB_SESSION_DEP,
    settings: Settings = SETTINGS_DEP,
) -> AuthPipeline:
    return AuthPipeline(UserRepository(session), redis, settings.auth)


AUTH_PIPELINE_DEP = Depends(get_auth_pipeline)


def require_user(
    credentials: HTTPAuthorizationCredentials | None = BEARER_DEP,
    settings: Settings = SETTINGS_DEP,
    redis: Redis = REDIS_DEP,
) -> UUID:
    if credentials is None:
        raise AuthTokenError("Missing bearer token")
    # Stateless access-token verification (no DB hit).
    pipeline = AuthPipeline(UserRepository(cast(AsyncSession, None)), redis, settings.auth)
    return pipeline.verify_access(credentials.credentials)


CURRENT_USER_DEP = Depends(require_user)


def get_household_repository(session: AsyncSession = DB_SESSION_DEP) -> HouseholdRepository:
    return HouseholdRepository(session)


def get_run_repository(session: AsyncSession = DB_SESSION_DEP) -> SimulationRunRepository:
    return SimulationRunRepository(session)


HOUSEHOLD_REPO_DEP = Depends(get_household_repository)
RUN_REPO_DEP = Depends(get_run_repository)
