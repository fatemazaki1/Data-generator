from __future__ import annotations

import logging
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from typing import cast

from asgi_correlation_id import CorrelationIdMiddleware
from fastapi import FastAPI
from redis.asyncio import Redis
from sqlalchemy.ext.asyncio import AsyncEngine
from starlette.middleware.cors import CORSMiddleware

from src.api.exception_handlers import register_exception_handlers
from src.api.routers import auth, households, presets, root, simulation
from src.bootstrap import setup_service, setup_settings
from src.workers.tasks import JobManager

logger = logging.getLogger(__name__)


def setup_app() -> FastAPI:
    settings = setup_settings()
    cors_origins = settings.app.cors_origin_list

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
        await setup_service(app)
        try:
            yield
        finally:
            await cast(JobManager, app.state.job_manager).shutdown()
            await cast(Redis, app.state.redis).aclose()
            await cast(AsyncEngine, app.state.db_engine).dispose()

    app = FastAPI(
        title="ha-energy-data-generator",
        description="Synthetic Home Assistant energy-consumption dataset generator",
        version="0.1.0",
        lifespan=lifespan,
    )
    app.add_middleware(CorrelationIdMiddleware)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_credentials=True,
        allow_methods=["GET", "PUT", "POST", "DELETE", "OPTIONS", "PATCH"],
        allow_headers=["*"],
    )
    register_exception_handlers(app)
    app.include_router(root.router, tags=["root"])
    app.include_router(auth.router, tags=["auth"])
    app.include_router(presets.router, tags=["catalog"])
    app.include_router(households.router, tags=["households"])
    app.include_router(simulation.router, tags=["simulations"])
    return app


app = setup_app()
