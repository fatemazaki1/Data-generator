from __future__ import annotations

from redis.asyncio import Redis

from src.config import Settings


async def setup_redis(settings: Settings) -> Redis:
    redis = Redis.from_url(settings.redis.url, decode_responses=True)
    await redis.ping()
    return redis
