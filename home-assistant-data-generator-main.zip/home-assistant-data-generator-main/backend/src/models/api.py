from __future__ import annotations

from datetime import date, datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from src.domain.catalog import (
    DeviceCategory,
    EstimatePeriod,
    LifestylePreset,
    RoomType,
)

# --------------------------------------------------------------------------- #
# Health / errors
# --------------------------------------------------------------------------- #


class ErrorResponse(BaseModel):
    detail: str


class ComponentStatus(BaseModel):
    ok: bool
    detail: str | None = None


class HealthResponse(BaseModel):
    status: str
    service: str


class ReadinessResponse(BaseModel):
    status: str
    service: str
    database: ComponentStatus
    redis: ComponentStatus


# --------------------------------------------------------------------------- #
# Auth
# --------------------------------------------------------------------------- #


class LoginRequest(BaseModel):
    username: str
    password: str


class RefreshRequest(BaseModel):
    refresh_token: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int


class MeResponse(BaseModel):
    user_id: UUID
    username: str


# --------------------------------------------------------------------------- #
# Catalog (read-only)
# --------------------------------------------------------------------------- #


class CategoryInfo(BaseModel):
    category: DeviceCategory
    archetype: str
    label: str
    default_kwh_per_day: float


class RoomTypeInfo(BaseModel):
    room_type: RoomType
    default_categories: list[DeviceCategory]


class LifestyleInfo(BaseModel):
    preset: LifestylePreset
    label: str


class CatalogResponse(BaseModel):
    categories: list[CategoryInfo]
    room_types: list[RoomTypeInfo]
    lifestyles: list[LifestyleInfo]


# --------------------------------------------------------------------------- #
# Household / room / device CRUD
# --------------------------------------------------------------------------- #


class DeviceCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    category: DeviceCategory
    kwh_estimate: float = Field(..., gt=0)
    estimate_period: EstimatePeriod = EstimatePeriod.DAY


class DeviceOut(DeviceCreate):
    model_config = ConfigDict(from_attributes=True)
    id: UUID


class RoomCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    room_type: RoomType
    devices: list[DeviceCreate] = Field(default_factory=list)


class RoomOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    name: str
    room_type: RoomType
    devices: list[DeviceOut]


class HouseholdCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)
    timezone: str = "Europe/Zurich"
    lifestyle: LifestylePreset
    holidays_country: str = Field("CH", min_length=2, max_length=8)
    rooms: list[RoomCreate] = Field(default_factory=list)


class HouseholdUpdate(BaseModel):
    name: str | None = None
    latitude: float | None = Field(None, ge=-90, le=90)
    longitude: float | None = Field(None, ge=-180, le=180)
    timezone: str | None = None
    lifestyle: LifestylePreset | None = None
    holidays_country: str | None = None


class HouseholdOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    name: str
    latitude: float
    longitude: float
    timezone: str
    lifestyle: LifestylePreset
    holidays_country: str
    rooms: list[RoomOut]
    created_at: datetime


class HouseholdSummary(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    name: str
    lifestyle: LifestylePreset
    created_at: datetime


# --------------------------------------------------------------------------- #
# Simulation
# --------------------------------------------------------------------------- #


class AwayPeriodIn(BaseModel):
    start: date
    end: date


class SimulationCreateRequest(BaseModel):
    household_id: UUID
    start_date: date
    n_days: int = Field(..., ge=5, le=1095)
    error_allowance_pct: float = Field(10.0, ge=0, le=50)
    seed: int | None = None
    away_periods: list[AwayPeriodIn] = Field(default_factory=list)


class ValidationOut(BaseModel):
    ok: bool
    errors: list[str]
    warnings: list[str]
    stats: dict[str, float]


class SimulationRunOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    status: str
    phase: str
    progress: int
    n_days: int
    seed: int
    validation: ValidationOut | None = None
    error_message: str | None = None
    created_at: datetime
    updated_at: datetime
