"""Naive-local hourly time grid.

The forecast model expects clock-naive local timestamps with exactly 24 rows per
calendar day (``YYYY-MM-DD HH:MM:SS``), strictly increasing, no gaps. We therefore
build the index by simple +1h stepping and NEVER localize/convert to a timezone —
doing so would create the duplicate/missing hours of DST transitions and break
strict monotonicity. The timezone is used only for weather alignment and the
holiday calendar, not for shifting emitted timestamps.
"""

from __future__ import annotations

from datetime import date, datetime

import numpy as np
import pandas as pd


def build_hourly_index(start_date: date, n_days: int) -> pd.DatetimeIndex:
    start = datetime(start_date.year, start_date.month, start_date.day, 0, 0, 0)
    periods = n_days * 24
    return pd.date_range(start=start, periods=periods, freq="h")


def calendar_features(index: pd.DatetimeIndex) -> dict[str, np.ndarray]:
    """Vectorised calendar arrays shared across all device kernels."""
    hour = index.hour.to_numpy()
    dow = index.dayofweek.to_numpy()  # Mon=0 .. Sun=6
    return {
        "hour": hour,
        "day_of_week": dow,
        "month": index.month.to_numpy(),
        "day_of_year": index.dayofyear.to_numpy(),
        "is_weekend": (dow >= 5).astype(np.float64),
    }
