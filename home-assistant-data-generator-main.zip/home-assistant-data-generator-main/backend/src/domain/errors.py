from __future__ import annotations

from uuid import UUID


class DomainError(Exception):
    """Base class for first-party business errors."""


class InvalidCredentialsError(DomainError):
    def __init__(self) -> None:
        super().__init__("Invalid username or password")


class AuthTokenError(DomainError):
    def __init__(self, message: str = "Invalid or expired token") -> None:
        super().__init__(message)


class HouseholdNotFoundError(DomainError):
    def __init__(self, household_id: UUID | str) -> None:
        super().__init__(f"Household not found: {household_id}")
        self.household_id = household_id


class RoomNotFoundError(DomainError):
    def __init__(self, room_id: UUID | str) -> None:
        super().__init__(f"Room not found: {room_id}")
        self.room_id = room_id


class DeviceNotFoundError(DomainError):
    def __init__(self, device_id: UUID | str) -> None:
        super().__init__(f"Device not found: {device_id}")
        self.device_id = device_id


class SimulationRunNotFoundError(DomainError):
    def __init__(self, run_id: UUID | str) -> None:
        super().__init__(f"Simulation run not found: {run_id}")
        self.run_id = run_id


class SimulationNotReadyError(DomainError):
    def __init__(self, run_id: UUID | str, status: str) -> None:
        super().__init__(f"Simulation {run_id} is not ready for download (status={status})")
        self.run_id = run_id
        self.status = status


class InvalidSimulationConfigError(DomainError):
    """Raised when the household/device configuration cannot produce valid data."""

    def __init__(self, message: str) -> None:
        super().__init__(message)


class SimulationValidationError(DomainError):
    """Raised when generated data fails the output-contract validator."""

    def __init__(self, problems: list[str]) -> None:
        super().__init__("Generated dataset failed validation: " + "; ".join(problems))
        self.problems = problems
