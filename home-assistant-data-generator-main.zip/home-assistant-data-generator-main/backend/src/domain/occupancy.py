"""Occupancy / activity model.

Turns a lifestyle preset into an hourly activity vector in [0, 1] over the whole
horizon. This is the signal that gives OCCUPANCY_DRIVEN devices their daily cycle
and weekday/weekend split, drives DHW draws and CYCLIC run probability, and shapes
the EV charge-day pattern. Holidays adopt the weekend curve; multi-day away blocks
drop activity to ~0.
"""

from __future__ import annotations

from datetime import date, timedelta

import numpy as np
import pandas as pd

from src.domain.catalog import LifestyleSpec
from src.domain.models import AwayPeriod


def build_away_mask(
    index: pd.DatetimeIndex,
    explicit: tuple[AwayPeriod, ...],
    away_week_prob: float,
    rng: np.random.Generator,
) -> np.ndarray:
    """Per-hour boolean mask: True when the household is away."""
    dates = index.date
    away = np.zeros(len(index), dtype=bool)

    for period in explicit:
        away |= (dates >= period.start) & (dates <= period.end)

    # Stochastic multi-day trips, one candidate per ISO week.
    if away_week_prob > 0:
        unique_days = sorted({d for d in dates})
        if unique_days:
            first = unique_days[0]
            last = unique_days[-1]
            n_weeks = (last - first).days // 7 + 1
            for w in range(n_weeks):
                if rng.random() < away_week_prob:
                    trip_len = int(rng.integers(2, 6))  # 2–5 days
                    offset = int(rng.integers(0, 7))
                    trip_start = first + timedelta(days=w * 7 + offset)
                    trip_end = trip_start + timedelta(days=trip_len - 1)
                    away |= (dates >= trip_start) & (dates <= trip_end)
    return away


def build_occupancy(
    index: pd.DatetimeIndex,
    lifestyle: LifestyleSpec,
    holidays: set[date],
    away_mask: np.ndarray,
    rng: np.random.Generator,
) -> np.ndarray:
    """Hourly activity in [0, 1]."""
    hour = index.hour.to_numpy()
    dow = index.dayofweek.to_numpy()
    dates = index.date

    weekday = np.asarray(lifestyle.occ_weekday, dtype=np.float64)
    weekend = np.asarray(lifestyle.occ_weekend, dtype=np.float64)

    is_weekend = dow >= 5
    is_holiday = np.array([d in holidays for d in dates], dtype=bool)
    use_weekend = is_weekend | is_holiday

    base = np.where(use_weekend, weekend[hour], weekday[hour])

    # Smooth multiplicative AR(1) jitter (mean ~1) so identical day-types differ.
    jitter = np.empty(len(index), dtype=np.float64)
    noise = rng.normal(0.0, 0.08, size=len(index))
    jitter[0] = 1.0 + noise[0]
    for i in range(1, len(index)):
        jitter[i] = 1.0 + 0.85 * (jitter[i - 1] - 1.0) + noise[i]

    occ = np.clip(base * jitter, 0.0, 1.0)
    occ[away_mask] = 0.0
    return occ
