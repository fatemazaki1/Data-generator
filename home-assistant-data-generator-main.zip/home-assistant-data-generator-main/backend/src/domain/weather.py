"""Weather series.

The forecast repo normally pulls hourly weather from the Open-Meteo *archive*
API. We support that (see ``repositories/weather_cache.py``) but also provide a
fully synthetic, deterministic fallback here so generation works offline and is
reproducible. Both produce the same schema; the simulator only consumes a
``pandas.DataFrame`` with these columns:

    temp_c, precipitation_mm, sunshine_min, wind_kmh,
    cloud_cover_pct, direct_radiation_wm2, humidity

This module is pure (no network) — Open-Meteo fetching lives in the repository
layer.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

WEATHER_COLUMNS = [
    "temp_c",
    "precipitation_mm",
    "sunshine_min",
    "wind_kmh",
    "cloud_cover_pct",
    "direct_radiation_wm2",
    "humidity",
]

T_BALANCE_HEAT = 15.0  # below this, heating demand accrues (°C)
T_BALANCE_COOL = 24.0  # above this, cooling demand accrues (°C)


def _ar1(rng: np.random.Generator, n: int, sigma: float, phi: float = 0.9) -> np.ndarray:
    """Stationary AR(1) noise series, mean 0."""
    noise = rng.normal(0.0, sigma, size=n)
    out = np.empty(n, dtype=np.float64)
    out[0] = noise[0]
    for i in range(1, n):
        out[i] = phi * out[i - 1] + noise[i]
    return out


def generate_synthetic_weather(
    index: pd.DatetimeIndex,
    latitude: float,
    longitude: float,
    rng: np.random.Generator,
) -> pd.DataFrame:
    n = len(index)
    hour = index.hour.to_numpy().astype(np.float64)
    doy = index.dayofyear.to_numpy().astype(np.float64)

    abs_lat = abs(latitude)
    # Plausible climate from latitude: warmer & milder near the equator.
    mean_temp = 16.0 - 0.28 * (abs_lat - 45.0)
    season_amp = 7.0 + 0.13 * abs_lat
    # Southern hemisphere: flip the seasonal phase.
    phase = 200.0 if latitude >= 0 else 200.0 + 182.0

    seasonal = mean_temp + season_amp * np.cos(2 * np.pi * (doy - phase) / 365.25)
    diurnal = 5.0 * np.cos(2 * np.pi * (hour - 15.0) / 24.0)
    temp = seasonal + diurnal + _ar1(rng, n, sigma=1.2, phi=0.92)

    # Cloud cover as a bounded AR(1) process around 45%.
    cloud_raw = 45.0 + _ar1(rng, n, sigma=12.0, phi=0.95)
    cloud = np.clip(cloud_raw, 0.0, 100.0)

    # Daylight bell (zero at night), stronger in summer, attenuated by cloud.
    summer_factor = 0.6 + 0.4 * np.cos(2 * np.pi * (doy - phase) / 365.25)
    daylight = np.clip(np.sin(np.pi * (hour - 6.0) / 12.0), 0.0, 1.0)
    clear_radiation = 850.0 * daylight * summer_factor
    radiation = np.clip(clear_radiation * (1.0 - cloud / 100.0), 0.0, None)
    sunshine = np.clip(60.0 * daylight * (1.0 - cloud / 100.0), 0.0, 60.0)

    # Precipitation: only when cloudy, and sparse.
    rain_draw = rng.random(n)
    precip = np.where(
        (cloud > 70.0) & (rain_draw > 0.85),
        rng.gamma(shape=1.2, scale=1.5, size=n),
        0.0,
    )

    wind = np.clip(8.0 + _ar1(rng, n, sigma=4.0, phi=0.9), 0.0, None)
    humidity = np.clip(70.0 - 0.8 * (temp - mean_temp) + _ar1(rng, n, sigma=6.0, phi=0.9),
                       20.0, 100.0)

    return pd.DataFrame(
        {
            "temp_c": np.round(temp, 2),
            "precipitation_mm": np.round(precip, 2),
            "sunshine_min": np.round(sunshine, 1),
            "wind_kmh": np.round(wind, 1),
            "cloud_cover_pct": np.round(cloud, 1),
            "direct_radiation_wm2": np.round(radiation, 1),
            "humidity": np.round(humidity, 1),
        },
        index=index,
    )


def derive_thermal(weather: pd.DataFrame) -> dict[str, np.ndarray]:
    """Heating/cooling degree-hours from the temperature series."""
    temp = weather["temp_c"].to_numpy()
    return {
        "temp_c": temp,
        "hdd_h": np.clip(T_BALANCE_HEAT - temp, 0.0, None),
        "cdd_h": np.clip(temp - T_BALANCE_COOL, 0.0, None),
        "sunshine_min": weather["sunshine_min"].to_numpy(),
    }
