"""Noise / error model.

Two layers, both mean-1 so they never bias the calibrated daily total:

* per-device multiplicative log-normal noise (strictly positive — no negative
  energy artifacts), with sigma combining the category default and the
  household-wide ``error_allowance_pct``;
* a single global household AR(1) term applied to the aggregate.
"""

from __future__ import annotations

import numpy as np


def effective_sigma(device_sigma: float, error_allowance_pct: float) -> float:
    allowance = max(error_allowance_pct, 0.0) / 100.0
    return float(np.sqrt(device_sigma**2 + allowance**2))


def device_noise(rng: np.random.Generator, n: int, sigma: float) -> np.ndarray:
    """Mean-1 log-normal multiplier of length ``n``."""
    if sigma <= 0:
        return np.ones(n, dtype=np.float64)
    return np.exp(rng.normal(-0.5 * sigma**2, sigma, size=n))


def global_household_noise(rng: np.random.Generator, n: int, sigma: float = 0.04) -> np.ndarray:
    """Mean-1 AR(1) multiplier applied to the summed household load."""
    noise = rng.normal(0.0, sigma, size=n)
    series = np.empty(n, dtype=np.float64)
    series[0] = noise[0]
    for i in range(1, n):
        series[i] = 0.7 * series[i - 1] + noise[i]
    # Recentre to mean 1.
    return np.clip(1.0 + series, 0.2, None)
