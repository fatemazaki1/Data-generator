"""Device behavioural archetypes.

Each kernel returns a per-hour kWh array over the full horizon that sums to the
device's calibrated target (``kwh_per_day * n_days``). The user's kWh estimate
sets the scale; the archetype sets the shape. Noise is applied later by the
simulator, so kernels are deterministic given the RNG passed for event sampling.

Kernels are vectorised numpy — no Python hour-loops on the critical path.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from src.domain.catalog import Archetype, CategorySpec


@dataclass
class SimContext:
    """Shared per-run arrays (length L = n_days * 24)."""

    n_hours: int
    n_days: int
    hour: np.ndarray
    day_index: np.ndarray  # 0-based day number for each hour
    is_weekend: np.ndarray
    temp_c: np.ndarray
    hdd_h: np.ndarray
    cdd_h: np.ndarray
    sunshine_min: np.ndarray
    occupancy: np.ndarray
    away_day: np.ndarray  # per-DAY boolean (length n_days)


def _scale_to_target(shape: np.ndarray, target_total: float) -> np.ndarray:
    total = float(shape.sum())
    if total <= 0:
        # Degenerate shape (e.g. mild climate, no degree-hours): spread evenly.
        return np.full(shape.shape, target_total / max(len(shape), 1), dtype=np.float64)
    return shape * (target_total / total)


def _ewma(values: np.ndarray, alpha: float) -> np.ndarray:
    out = np.empty_like(values, dtype=np.float64)
    out[0] = values[0]
    for i in range(1, len(values)):
        out[i] = alpha * values[i] + (1 - alpha) * out[i - 1]
    return out


def kernel_always_on(target_total: float, ctx: SimContext) -> np.ndarray:
    # Near-constant with a faint defrost/duty ripple; guarantees > 0 everywhere.
    ripple = 1.0 + 0.06 * np.sin(2 * np.pi * np.arange(ctx.n_hours) / 13.0)
    return _scale_to_target(ripple, target_total)


def kernel_thermostatic(target_total: float, ctx: SimContext, spec: CategorySpec) -> np.ndarray:
    if spec.is_dhw:
        return _kernel_dhw(target_total, ctx, spec)

    demand = np.zeros(ctx.n_hours, dtype=np.float64)
    if spec.heating:
        cop_heat = np.clip(3.5 + 0.05 * (ctx.temp_c - 7.0), 1.8, 4.5)
        demand += ctx.hdd_h / cop_heat
    if spec.cooling:
        cop_cool = 3.0
        demand += ctx.cdd_h / cop_cool
    # Thermal inertia: EWMA smooths demand into the lagged shape the model's
    # lag/EWMA features are built to capture.
    shape = _ewma(demand, alpha=0.3)
    return _scale_to_target(shape, target_total)


def _kernel_dhw(target_total: float, ctx: SimContext, spec: CategorySpec) -> np.ndarray:
    tod = np.asarray(spec.tod_weights, dtype=np.float64)[ctx.hour]
    # Standby tank loss + occupancy-coupled draw events.
    shape = 0.25 + ctx.occupancy * tod
    shape = _ewma(shape, alpha=0.4)
    return _scale_to_target(shape, target_total)


def kernel_occupancy(target_total: float, ctx: SimContext, spec: CategorySpec,
                     daylight_gated: bool) -> np.ndarray:
    tod = np.asarray(spec.tod_weights, dtype=np.float64)[ctx.hour]
    shape = ctx.occupancy * tod
    if daylight_gated:
        # Lights are used when occupied *and* dark.
        gate = np.clip(1.0 - ctx.sunshine_min / 60.0, 0.1, 1.0)
        shape = shape * gate
    return _scale_to_target(shape, target_total)


def kernel_cyclic(target_total: float, ctx: SimContext, spec: CategorySpec,
                  rng: np.random.Generator) -> np.ndarray:
    out = np.zeros(ctx.n_hours, dtype=np.float64)
    if target_total <= 0:
        return out
    n_runs = max(int(round(target_total / max(spec.cycle_kwh, 1e-6))), 1)

    tod = np.asarray(spec.tod_weights, dtype=np.float64)
    # Per-hour start weight for each day = tod * mean daily occupancy preference.
    cycle_profile = _run_profile(spec.cycle_kwh, spec.cycle_hours)

    for _ in range(n_runs):
        # Pick a non-away day, weekend-biased.
        day_weights = np.where(ctx.away_day, 0.0, 1.0) * (1.0 + 0.4 * _weekend_per_day(ctx))
        if day_weights.sum() <= 0:
            day = int(rng.integers(0, ctx.n_days))
        else:
            day = int(rng.choice(ctx.n_days, p=day_weights / day_weights.sum()))
        start_hour = int(rng.choice(24, p=tod / tod.sum()))
        base = day * 24 + start_hour
        for k, frac in enumerate(cycle_profile):
            idx = base + k
            if idx < ctx.n_hours:
                out[idx] += frac
    # Honour the user's estimate exactly despite integer run counts.
    return _scale_to_target(out, target_total)


def kernel_ev(target_total: float, ctx: SimContext, spec: CategorySpec,
              charge_day_prob: float, rng: np.random.Generator) -> np.ndarray:
    out = np.zeros(ctx.n_hours, dtype=np.float64)
    if target_total <= 0:
        return out
    tod = np.asarray(spec.tod_weights, dtype=np.float64)

    for day in range(ctx.n_days):
        if ctx.away_day[day]:
            continue
        if rng.random() > charge_day_prob:
            continue
        energy = max(float(rng.normal(spec.session_kwh, spec.session_kwh * 0.2)), 1.0)
        start_hour = int(rng.choice(24, p=tod / tod.sum()))
        hours_needed = int(np.ceil(energy / spec.charger_kw))
        remaining = energy
        for k in range(hours_needed):
            idx = day * 24 + start_hour + k
            if idx >= ctx.n_hours:
                break
            draw = min(spec.charger_kw, remaining)
            out[idx] += draw
            remaining -= draw
    return _scale_to_target(out, target_total)


def _run_profile(cycle_kwh: float, cycle_hours: int) -> list[float]:
    # Front-loaded heating profile (washers/dryers peak early in the cycle).
    if cycle_hours <= 1:
        return [cycle_kwh]
    weights = np.linspace(1.0, 0.5, cycle_hours)
    weights = weights / weights.sum()
    return list(cycle_kwh * weights)


def _weekend_per_day(ctx: SimContext) -> np.ndarray:
    # Reduce per-hour weekend flag to a per-day flag.
    return ctx.is_weekend.reshape(ctx.n_days, 24)[:, 0]


def run_kernel(target_total: float, ctx: SimContext, spec: CategorySpec,
               rng: np.random.Generator, *, daylight_gated: bool,
               charge_day_prob: float) -> np.ndarray:
    if spec.archetype is Archetype.ALWAYS_ON:
        return kernel_always_on(target_total, ctx)
    if spec.archetype is Archetype.THERMOSTATIC:
        return kernel_thermostatic(target_total, ctx, spec)
    if spec.archetype is Archetype.OCCUPANCY_DRIVEN:
        return kernel_occupancy(target_total, ctx, spec, daylight_gated)
    if spec.archetype is Archetype.CYCLIC:
        return kernel_cyclic(target_total, ctx, spec, rng)
    if spec.archetype is Archetype.EV_CHARGER:
        return kernel_ev(target_total, ctx, spec, charge_day_prob, rng)
    raise ValueError(f"Unknown archetype: {spec.archetype}")
