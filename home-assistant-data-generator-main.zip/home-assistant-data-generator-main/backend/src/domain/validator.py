"""Post-generation validator.

Hard checks assert the output satisfies every constraint the forecast model and
its backfill impose; failing any of them blocks the download. Soft checks warn
when the data may be too featureless to train well (no daily cycle, no
weekday/weekend split, no weather correlation).
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from src.domain.simulator import MAX_HOURLY_KWH, MIN_HOURLY_KWH, SimulationResult

MIN_TRAINING_ROWS = 100
MAX_GAP_HOURS = 2


@dataclass
class ValidationReport:
    ok: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    stats: dict[str, float] = field(default_factory=dict)


def validate(result: SimulationResult, has_thermostatic: bool) -> ValidationReport:
    errors: list[str] = []
    warnings: list[str] = []

    index = result.index
    gross = result.gross_kwh
    n = len(index)

    # --- Hard checks --------------------------------------------------------
    if n < MIN_TRAINING_ROWS:
        errors.append(f"Only {n} rows; need >= {MIN_TRAINING_ROWS} to train.")

    if np.any(~np.isfinite(gross)):
        errors.append("gross_kwh contains NaN/inf values.")

    if np.any(gross <= 0):
        errors.append("gross_kwh has non-positive values (must be > 0).")
    if np.any(gross > MAX_HOURLY_KWH):
        errors.append(f"gross_kwh exceeds {MAX_HOURLY_KWH} kWh/h cap.")
    if np.any(gross < MIN_HOURLY_KWH):
        errors.append(f"gross_kwh below floor {MIN_HOURLY_KWH}.")

    # Work in integer seconds so the checks are independent of the datetime
    # resolution (pandas 2 = ns, pandas 3 = us).
    deltas = np.diff(index.as_unit("s").asi8)
    if n > 1:
        if np.any(deltas <= 0):
            errors.append("Timestamps are not strictly monotonic increasing.")
        if np.any(deltas > MAX_GAP_HOURS * 3600):
            errors.append(f"Gap larger than {MAX_GAP_HOURS}h found in timestamps.")

    # Cumulative sum must be non-decreasing and reproduce gross via diffs
    # (this is exactly what the HA backfill does).
    cum = result.cumulative_kwh
    cum_diff = np.diff(cum, prepend=0.0)
    if np.any(np.diff(cum) < 0):
        errors.append("Cumulative sum is not non-decreasing.")
    if not np.allclose(cum_diff, gross, atol=1e-6):
        errors.append("Cumulative diffs do not reproduce gross_kwh.")

    # Per-appliance sums must reconcile with gross (within global-noise tolerance).
    if result.per_device:
        device_sum = np.sum([arr for _, arr in result.per_device.values()], axis=0)
        ratio = float(device_sum.sum()) / max(float(gross.sum()), 1e-9)
        if not (0.85 <= ratio <= 1.15):
            warnings.append(
                f"Per-appliance total deviates from grid total by {abs(1 - ratio) * 100:.0f}% "
                "(expected within global-noise tolerance)."
            )

    # --- Soft (learnability) checks ----------------------------------------
    hours = index.hour.to_numpy()
    hourly_means = np.array([gross[hours == h].mean() for h in range(24)])
    if hourly_means.std() / max(hourly_means.mean(), 1e-9) < 0.05:
        warnings.append("Weak hour-of-day variation — model may struggle to learn a daily cycle.")

    dow = index.dayofweek.to_numpy()
    weekday_mean = gross[dow < 5].mean() if np.any(dow < 5) else 0.0
    weekend_mean = gross[dow >= 5].mean() if np.any(dow >= 5) else 0.0
    if weekday_mean and abs(weekday_mean - weekend_mean) / weekday_mean < 0.03:
        warnings.append("Weekday and weekend load are nearly identical.")

    if has_thermostatic:
        temp = result.weather["temp_c"].to_numpy()
        hdd = np.clip(15.0 - temp, 0.0, None)
        if np.std(hdd) > 0 and np.std(gross) > 0:
            corr = float(np.corrcoef(gross, hdd)[0, 1])
            if abs(corr) < 0.1:
                warnings.append(
                    "Low correlation between load and heating demand despite a "
                    "thermostatic device — seasonal signal may be weak."
                )

    stats = {
        "rows": float(n),
        "total_kwh": float(gross.sum()),
        "mean_daily_kwh": float(result.meta.get("mean_daily_kwh", 0.0)),
        "weekday_mean_kwh": float(weekday_mean),
        "weekend_mean_kwh": float(weekend_mean),
        "peak_hour_kwh": float(gross.max()),
    }
    return ValidationReport(ok=not errors, errors=errors, warnings=warnings, stats=stats)
