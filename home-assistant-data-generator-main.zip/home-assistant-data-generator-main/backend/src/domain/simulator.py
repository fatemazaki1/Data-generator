"""Simulation orchestrator.

Builds the full hourly horizon in one vectorised pass (a few MB even for two
years), so there are no block-boundary discontinuities in the EWMA/AR(1) signals.
The worker layer handles progress/checkpointing around this; because the engine is
deterministic given the seed, a resumed job re-runs ``simulate`` and continues
from the export phase.
"""

from __future__ import annotations

import zlib
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from src.domain import weather as weather_mod
from src.domain.archetypes import SimContext, run_kernel
from src.domain.catalog import (
    CATEGORY_SPECS,
    LIFESTYLE_SPECS,
    DeviceCategory,
)
from src.domain.errors import InvalidSimulationConfigError
from src.domain.models import DeviceSpec, SimulationConfig
from src.domain.noise import device_noise, effective_sigma, global_household_noise
from src.domain.occupancy import build_away_mask, build_occupancy
from src.domain.timeindex import build_hourly_index, calendar_features

MIN_HOURLY_KWH = 0.01
MAX_HOURLY_KWH = 50.0


@dataclass
class SimulationResult:
    index: pd.DatetimeIndex
    gross_kwh: np.ndarray
    cumulative_kwh: np.ndarray
    weather: pd.DataFrame
    per_device: dict[str, tuple[str, np.ndarray]]  # statistic_id -> (display name, kwh array)
    grid_sensor_id: str
    meta: dict[str, float] = field(default_factory=dict)


def _stable_int(value: str) -> int:
    return int(zlib.crc32(value.encode("utf-8")))


def _holiday_set(country: str, index: pd.DatetimeIndex) -> set:
    try:
        import holidays as holidays_lib

        years = sorted({d.year for d in index.date})
        cal = holidays_lib.country_holidays(country.upper(), years=years)
        return set(cal.keys())
    except Exception:
        return set()


def simulate(config: SimulationConfig, weather_df: pd.DataFrame | None = None) -> SimulationResult:
    household = config.household
    if not config.devices:
        raise InvalidSimulationConfigError("At least one device is required to simulate.")
    if household.n_days < 5:
        raise InvalidSimulationConfigError("Simulation horizon must be at least 5 days.")

    index = build_hourly_index(household.start_date, household.n_days)
    n_hours = len(index)
    cal = calendar_features(index)

    # Weather: use the injected (Open-Meteo) series if provided, else synthetic.
    if weather_df is None:
        ss_weather = np.random.SeedSequence([household.master_seed, _stable_int("weather")])
        rng_weather = np.random.default_rng(ss_weather)
        weather_df = weather_mod.generate_synthetic_weather(
            index, household.latitude, household.longitude, rng_weather
        )
    else:
        weather_df = weather_df.reindex(index).interpolate().ffill().bfill()
    thermal = weather_mod.derive_thermal(weather_df)

    # Occupancy + away pattern.
    lifestyle = LIFESTYLE_SPECS[household.lifestyle]
    ss_occ = np.random.SeedSequence([household.master_seed, _stable_int("occupancy")])
    rng_occ = np.random.default_rng(ss_occ)
    away_mask = build_away_mask(
        index, household.away_periods, lifestyle.away_week_prob, rng_occ
    )
    holidays = _holiday_set(household.holidays_country, index)
    occupancy = build_occupancy(index, lifestyle, holidays, away_mask, rng_occ)
    away_day = away_mask.reshape(household.n_days, 24).any(axis=1)

    ctx = SimContext(
        n_hours=n_hours,
        n_days=household.n_days,
        hour=cal["hour"],
        day_index=np.repeat(np.arange(household.n_days), 24),
        is_weekend=cal["is_weekend"],
        temp_c=thermal["temp_c"],
        hdd_h=thermal["hdd_h"],
        cdd_h=thermal["cdd_h"],
        sunshine_min=thermal["sunshine_min"],
        occupancy=occupancy,
        away_day=away_day,
    )

    per_device: dict[str, tuple[str, np.ndarray]] = {}
    total_matrix = np.zeros(n_hours, dtype=np.float64)

    for device in config.devices:
        series = _simulate_device(device, ctx, household.error_allowance_pct,
                                  household.master_seed, lifestyle.ev_charge_day_prob)
        per_device[device.statistic_id] = (device.name, series)
        total_matrix = total_matrix + series

    # Global household noise on the aggregate, then enforce hard bounds.
    ss_global = np.random.SeedSequence([household.master_seed, _stable_int("global")])
    rng_global = np.random.default_rng(ss_global)
    gross = total_matrix * global_household_noise(rng_global, n_hours)
    gross = np.clip(gross, MIN_HOURLY_KWH, MAX_HOURLY_KWH)
    gross = np.round(gross, 4)

    cumulative = np.cumsum(gross)

    meta = {
        "total_kwh": float(gross.sum()),
        "mean_daily_kwh": float(gross.sum() / household.n_days),
        "peak_hour_kwh": float(gross.max()),
        "n_clamped_high": float(np.count_nonzero(total_matrix > MAX_HOURLY_KWH)),
    }
    return SimulationResult(
        index=index,
        gross_kwh=gross,
        cumulative_kwh=cumulative,
        weather=weather_df,
        per_device=per_device,
        grid_sensor_id=household.grid_sensor_id,
        meta=meta,
    )


def _simulate_device(
    device: DeviceSpec,
    ctx: SimContext,
    error_allowance_pct: float,
    master_seed: int,
    ev_charge_day_prob: float,
) -> np.ndarray:
    spec = CATEGORY_SPECS[device.category]
    target_total = device.kwh_per_day * ctx.n_days

    ss = np.random.SeedSequence([master_seed, _stable_int(device.device_id)])
    rng = np.random.default_rng(ss)

    daylight_gated = device.category is DeviceCategory.LIGHTING
    shape = run_kernel(
        target_total, ctx, spec, rng,
        daylight_gated=daylight_gated,
        charge_day_prob=ev_charge_day_prob,
    )

    sigma = effective_sigma(spec.noise_sigma, error_allowance_pct)
    noisy = shape * device_noise(rng, ctx.n_hours, sigma)
    return np.clip(noisy, 0.0, None)
