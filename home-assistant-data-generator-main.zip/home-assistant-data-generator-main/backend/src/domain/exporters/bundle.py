"""Assembles all output artifacts into a single downloadable zip."""

from __future__ import annotations

import zipfile
from pathlib import Path

from src.domain.exporters.apps_yaml import write_apps_yaml
from src.domain.exporters.csv import (
    write_appliance_csvs,
    write_energy_history,
    write_weather,
)
from src.domain.exporters.sqlite import write_sqlite
from src.domain.models import HouseholdSpec
from src.domain.simulator import SimulationResult

_README = """# Synthetic Home Assistant energy dataset

Generated for the `ha-energy-forecast` AppDaemon app.

## Contents
- `energy_history.csv`   — primary training input (timestamp, gross_kwh; hourly).
- `weather.csv`          — matching hourly weather series.
- `home-assistant_v2.db` — HA recorder statistics (run the repo's backfill against this).
- `appliances/*.csv`     — per-device hourly kWh (optional sub-sensor tracking).
- `apps.yaml`            — ready-to-use AppDaemon config snippet.

## How to use
1. Copy `energy_history.csv` next to the energy_forecast app, OR
2. Point the backfill app at `home-assistant_v2.db` (entity id is in apps.yaml).
3. The model trains automatically once enough history is present (>= 100 rows).
"""


def write_bundle(
    result: SimulationResult, household: HouseholdSpec, out_dir: Path
) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    write_energy_history(result, out_dir)
    write_weather(result, out_dir)
    write_appliance_csvs(result, out_dir)
    write_sqlite(result, out_dir, timezone=household.timezone)
    write_apps_yaml(household, out_dir)
    (out_dir / "README.md").write_text(_README, encoding="utf-8")

    zip_path = out_dir.parent / f"{out_dir.name}.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(out_dir.rglob("*")):
            if path.is_file():
                zf.write(path, path.relative_to(out_dir))
    return zip_path
