"""Home Assistant ``home-assistant_v2.db`` exporter.

Reproduces the subset of the HA recorder schema that ha-energy-forecast's backfill
reads: ``statistics_meta`` + ``statistics`` with a monotonic cumulative ``sum``.
The backfill diffs consecutive ``sum`` values (clamping negatives to 0, discarding
> 50 kWh/h), so ``sum = cumsum(gross_kwh)`` reproduces every hour exactly.

``start_ts`` is unix epoch seconds. We treat the naive-local timestamps as a fixed
reference frame (epoch of the naive value); only the *diffs* matter to the backfill,
so the absolute offset is irrelevant and this stays deterministic.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

import numpy as np
import pandas as pd

from src.domain.simulator import SimulationResult


def _epoch_seconds(index: pd.DatetimeIndex, timezone: str) -> np.ndarray:
    """Naive-local timestamps → Unix epoch seconds of the matching UTC instant.

    The backfill reads ``start_ts`` as UTC then converts to the configured
    timezone, so we must store the true UTC instant for each local time. This
    makes the SQLite path reconstruct exactly the same naive-local timestamps as
    ``energy_history.csv``. DST gaps/repeats are resolved deterministically.
    """
    try:
        localized = index.tz_localize(
            timezone, nonexistent="shift_forward", ambiguous="infer"
        )
    except Exception:
        # Ambiguous inference can fail on short ranges; fall back to UTC framing.
        localized = index.tz_localize("UTC")
    # as_unit("s") makes this independent of the index's datetime resolution
    # (pandas 2 defaults to ns, pandas 3 to us).
    return localized.tz_convert("UTC").as_unit("s").asi8.astype("int64")


def _create_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS statistics_meta (
            id INTEGER PRIMARY KEY,
            statistic_id TEXT UNIQUE NOT NULL,
            source TEXT,
            unit_of_measurement TEXT,
            has_mean INTEGER,
            has_sum INTEGER,
            name TEXT
        );
        CREATE TABLE IF NOT EXISTS statistics (
            id INTEGER PRIMARY KEY,
            metadata_id INTEGER NOT NULL,
            created REAL,
            created_ts REAL,
            start_ts REAL,
            mean REAL,
            min REAL,
            max REAL,
            last_reset_ts REAL,
            state REAL,
            sum REAL
        );
        CREATE INDEX IF NOT EXISTS ix_statistics_meta_id
            ON statistics (metadata_id, start_ts);
        """
    )


def _insert_series(
    conn: sqlite3.Connection,
    metadata_id: int,
    statistic_id: str,
    name: str,
    epochs: np.ndarray,
    per_hour: np.ndarray,
) -> None:
    conn.execute(
        "INSERT INTO statistics_meta "
        "(id, statistic_id, source, unit_of_measurement, has_mean, has_sum, name) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (metadata_id, statistic_id, "recorder", "kWh", 0, 1, name),
    )
    cumulative = np.cumsum(per_hour)
    rows = [
        (
            metadata_id,
            float(epochs[i]),
            float(epochs[i]),
            float(per_hour[i]),  # state: meter reading proxy
            float(cumulative[i]),  # sum: cumulative total the backfill diffs
        )
        for i in range(len(epochs))
    ]
    conn.executemany(
        "INSERT INTO statistics "
        "(metadata_id, created_ts, start_ts, state, sum) VALUES (?, ?, ?, ?, ?)",
        rows,
    )


def write_sqlite(result: SimulationResult, out_dir: Path, timezone: str = "UTC") -> Path:
    path = out_dir / "home-assistant_v2.db"
    if path.exists():
        path.unlink()
    epochs = _epoch_seconds(result.index, timezone)

    conn = sqlite3.connect(path)
    try:
        _create_schema(conn)
        # metadata_id 1 = the grid-import sensor (the model's primary input).
        _insert_series(
            conn, 1, result.grid_sensor_id, "Grid import energy",
            epochs, result.gross_kwh,
        )
        for i, (statistic_id, (name, series)) in enumerate(result.per_device.items(), start=2):
            _insert_series(conn, i, statistic_id, name, epochs, series)
        conn.commit()
    finally:
        conn.close()
    return path
