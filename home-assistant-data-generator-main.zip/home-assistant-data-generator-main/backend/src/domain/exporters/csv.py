"""CSV exporters matching ha-energy-forecast's expected inputs."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from src.domain.simulator import SimulationResult

TS_FORMAT = "%Y-%m-%d %H:%M:%S"


def _timestamps(index: pd.DatetimeIndex) -> pd.Series:
    return pd.Series(index.strftime(TS_FORMAT), name="timestamp")


def write_energy_history(result: SimulationResult, out_dir: Path) -> Path:
    """The core training input: timestamp, gross_kwh (hourly, naive local)."""
    path = out_dir / "energy_history.csv"
    frame = pd.DataFrame(
        {
            "timestamp": _timestamps(result.index),
            "gross_kwh": result.gross_kwh,
        }
    )
    frame.to_csv(path, index=False)
    return path


def write_weather(result: SimulationResult, out_dir: Path) -> Path:
    path = out_dir / "weather.csv"
    frame = result.weather.copy()
    frame.insert(0, "timestamp", result.index.strftime(TS_FORMAT))
    frame.to_csv(path, index=False)
    return path


def write_appliance_csvs(result: SimulationResult, out_dir: Path) -> list[Path]:
    """One CSV per device: timestamp, kwh (per-hour)."""
    appliance_dir = out_dir / "appliances"
    appliance_dir.mkdir(parents=True, exist_ok=True)
    paths: list[Path] = []
    ts = _timestamps(result.index)
    for statistic_id, (_, series) in result.per_device.items():
        path = appliance_dir / f"{statistic_id}.csv"
        pd.DataFrame({"timestamp": ts, "kwh": series.round(4)}).to_csv(path, index=False)
        paths.append(path)
    return paths
