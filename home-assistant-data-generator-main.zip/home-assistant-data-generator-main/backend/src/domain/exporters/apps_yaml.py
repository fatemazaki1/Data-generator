"""AppDaemon ``apps.yaml`` snippet generator for ha-energy-forecast."""

from __future__ import annotations

from pathlib import Path

from src.domain.models import HouseholdSpec


def render_apps_yaml(household: HouseholdSpec) -> str:
    return (
        "# Drop this into your AppDaemon apps.yaml for ha-energy-forecast.\n"
        "# Place energy_history.csv next to the app (or run the backfill against\n"
        "# the bundled home-assistant_v2.db).\n"
        "energy_forecast:\n"
        "  module: energy_forecast.energy_forecast\n"
        "  class: EnergyForecast\n"
        f"  energy_sensor: {household.grid_sensor_id}\n"
        f"  latitude: {household.latitude}\n"
        f"  longitude: {household.longitude}\n"
        f"  timezone: {household.timezone}\n"
        f"  holiday_country: {household.holidays_country}\n"
    )


def write_apps_yaml(household: HouseholdSpec, out_dir: Path) -> Path:
    path = out_dir / "apps.yaml"
    path.write_text(render_apps_yaml(household), encoding="utf-8")
    return path
