"""Immutable specs consumed by the simulation engine. These are plain
dataclasses (no FastAPI/Pydantic) so ``domain`` stays framework-free and
trivially unit-testable. The API layer maps its Pydantic DTOs onto these.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date

from src.domain.catalog import (
    CATEGORY_SPECS,
    PERIOD_DAYS,
    DeviceCategory,
    EstimatePeriod,
    LifestylePreset,
    RoomType,
)

_SLUG_RE = re.compile(r"[^a-z0-9]+")


def _slugify(value: str) -> str:
    slug = _SLUG_RE.sub("_", value.lower()).strip("_")
    return slug or "device"


@dataclass(frozen=True)
class DeviceSpec:
    device_id: str
    name: str
    category: DeviceCategory
    room_type: RoomType
    kwh_estimate: float
    estimate_period: EstimatePeriod = EstimatePeriod.DAY

    @property
    def kwh_per_day(self) -> float:
        """Normalise the user's estimate to an average kWh/day."""
        return self.kwh_estimate / PERIOD_DAYS[self.estimate_period]

    @property
    def statistic_id(self) -> str:
        """Home Assistant entity / statistic id for the per-appliance sensor."""
        return f"sensor.{_slugify(self.name)}_energy"

    @property
    def archetype(self) -> str:
        return CATEGORY_SPECS[self.category].archetype.value


@dataclass(frozen=True)
class AwayPeriod:
    start: date
    end: date  # inclusive


@dataclass(frozen=True)
class HouseholdSpec:
    latitude: float
    longitude: float
    timezone: str
    start_date: date
    n_days: int
    lifestyle: LifestylePreset
    error_allowance_pct: float = 10.0
    holidays_country: str = "CH"
    grid_sensor_id: str = "sensor.grid_import_energy"
    master_seed: int = 1
    away_periods: tuple[AwayPeriod, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class SimulationConfig:
    household: HouseholdSpec
    devices: tuple[DeviceSpec, ...]

    @property
    def n_hours(self) -> int:
        return self.n_days * 24

    @property
    def n_days(self) -> int:
        return self.household.n_days
