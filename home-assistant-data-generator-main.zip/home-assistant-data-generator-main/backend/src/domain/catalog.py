"""Static catalog: room types, device categories → behavioural archetypes, and
lifestyle presets. This is the single source of truth shared by the simulation
engine (``simulator.py``) and the read-only catalog API (``routers/presets.py``).

All numbers are intentionally explicit and documented so the simulated output is
realistic and auditable. The user's per-device kWh *estimate* always sets the
scale; the archetype only sets the *shape* of consumption over the day/season.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

# --------------------------------------------------------------------------- #
# Enums
# --------------------------------------------------------------------------- #


class RoomType(str, Enum):
    KITCHEN = "kitchen"
    LIVING_ROOM = "living_room"
    BEDROOM = "bedroom"
    BATHROOM = "bathroom"
    HOME_OFFICE = "home_office"
    GARAGE = "garage"
    UTILITY = "utility"
    HALLWAY = "hallway"
    OUTDOOR = "outdoor"


class Archetype(str, Enum):
    ALWAYS_ON = "always_on"
    THERMOSTATIC = "thermostatic"
    OCCUPANCY_DRIVEN = "occupancy_driven"
    CYCLIC = "cyclic"
    EV_CHARGER = "ev_charger"


class DeviceCategory(str, Enum):
    REFRIGERATOR = "refrigerator"
    FREEZER = "freezer"
    NETWORK = "network"  # router/modem/NAS
    STANDBY = "standby"  # always-on electronics baseline
    HEAT_PUMP = "heat_pump"
    AIR_CONDITIONER = "air_conditioner"
    ELECTRIC_HEATER = "electric_heater"
    WATER_HEATER = "water_heater"
    LIGHTING = "lighting"
    TV = "tv"
    COMPUTER = "computer"
    OVEN = "oven"
    SMALL_APPLIANCE = "small_appliance"  # kettle, microwave, toaster
    DISHWASHER = "dishwasher"
    WASHING_MACHINE = "washing_machine"
    DRYER = "dryer"
    EV_CHARGER = "ev_charger"


class LifestylePreset(str, Enum):
    FAMILY_WITH_KIDS = "family_with_kids"
    COUPLE_WORKING = "couple_working"
    WORK_FROM_HOME = "work_from_home"
    SINGLE = "single"
    RETIRED = "retired"
    FREQUENTLY_AWAY = "frequently_away"


class EstimatePeriod(str, Enum):
    DAY = "day"
    WEEK = "week"
    MONTH = "month"
    YEAR = "year"


# --------------------------------------------------------------------------- #
# Estimate-period → days, used to normalise the user's kWh estimate to kWh/day.
# --------------------------------------------------------------------------- #

PERIOD_DAYS: dict[EstimatePeriod, float] = {
    EstimatePeriod.DAY: 1.0,
    EstimatePeriod.WEEK: 7.0,
    EstimatePeriod.MONTH: 30.4375,
    EstimatePeriod.YEAR: 365.25,
}


# --------------------------------------------------------------------------- #
# Device archetype defaults
# --------------------------------------------------------------------------- #


@dataclass(frozen=True)
class CategorySpec:
    """Default behavioural parameters for one device category."""

    category: DeviceCategory
    archetype: Archetype
    label: str
    default_kwh_per_day: float
    # Time-of-day weight (24 values, relative). Used by OCCUPANCY_DRIVEN / CYCLIC
    # to shape *when* the device draws power. Need not be normalised.
    tod_weights: tuple[float, ...] = field(default_factory=lambda: tuple([1.0] * 24))
    # THERMOSTATIC: which mode(s) the device serves.
    heating: bool = False
    cooling: bool = False
    is_dhw: bool = False  # domestic hot water (occupancy-coupled draws)
    # CYCLIC: energy per cycle (kWh) and run duration (hours).
    cycle_kwh: float = 1.0
    cycle_hours: int = 1
    # EV_CHARGER: charger power (kW) and typical session energy (kWh).
    charger_kw: float = 7.4
    session_kwh: float = 10.0
    # Per-device multiplicative noise sigma (lognormal). Combined with the
    # household-wide error allowance at runtime.
    noise_sigma: float = 0.05
    # Whether the device's daily total scales with heating/cooling degree-days
    # rather than being a fixed daily energy (THERMOSTATIC only).
    weather_scaled: bool = False


# Hour-of-day shape helpers (length 24, hour 0..23, local time).
_EVENING = (0.2, 0.1, 0.1, 0.1, 0.1, 0.15, 0.3, 0.5, 0.4, 0.3, 0.3, 0.35,
            0.4, 0.35, 0.3, 0.35, 0.5, 0.8, 1.0, 1.0, 0.95, 0.8, 0.6, 0.35)
_MEALS = (0.0, 0.0, 0.0, 0.0, 0.0, 0.05, 0.2, 0.7, 0.5, 0.15, 0.1, 0.4,
          0.9, 0.5, 0.15, 0.1, 0.15, 0.4, 0.9, 1.0, 0.5, 0.2, 0.1, 0.05)
_MORNING_EVENING = (0.1, 0.05, 0.05, 0.05, 0.05, 0.2, 0.6, 0.9, 0.6, 0.3, 0.25, 0.3,
                    0.4, 0.3, 0.25, 0.3, 0.4, 0.6, 0.8, 0.9, 0.7, 0.5, 0.3, 0.15)
_DAYTIME = (0.05, 0.05, 0.05, 0.05, 0.05, 0.1, 0.3, 0.6, 0.8, 0.9, 0.95, 0.9,
            0.85, 0.9, 0.95, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1)
_FLAT = tuple([1.0] * 24)


CATEGORY_SPECS: dict[DeviceCategory, CategorySpec] = {
    DeviceCategory.REFRIGERATOR: CategorySpec(
        DeviceCategory.REFRIGERATOR, Archetype.ALWAYS_ON, "Refrigerator",
        default_kwh_per_day=1.0, noise_sigma=0.03,
    ),
    DeviceCategory.FREEZER: CategorySpec(
        DeviceCategory.FREEZER, Archetype.ALWAYS_ON, "Freezer",
        default_kwh_per_day=1.2, noise_sigma=0.03,
    ),
    DeviceCategory.NETWORK: CategorySpec(
        DeviceCategory.NETWORK, Archetype.ALWAYS_ON, "Router / network gear",
        default_kwh_per_day=0.4, noise_sigma=0.02,
    ),
    DeviceCategory.STANDBY: CategorySpec(
        DeviceCategory.STANDBY, Archetype.ALWAYS_ON, "Standby electronics",
        default_kwh_per_day=0.6, noise_sigma=0.04,
    ),
    DeviceCategory.HEAT_PUMP: CategorySpec(
        DeviceCategory.HEAT_PUMP, Archetype.THERMOSTATIC, "Heat pump (heating + cooling)",
        default_kwh_per_day=8.0, heating=True, cooling=True, weather_scaled=True,
        noise_sigma=0.08,
    ),
    DeviceCategory.AIR_CONDITIONER: CategorySpec(
        DeviceCategory.AIR_CONDITIONER, Archetype.THERMOSTATIC, "Air conditioner",
        default_kwh_per_day=3.0, cooling=True, weather_scaled=True, noise_sigma=0.1,
    ),
    DeviceCategory.ELECTRIC_HEATER: CategorySpec(
        DeviceCategory.ELECTRIC_HEATER, Archetype.THERMOSTATIC, "Electric heater",
        default_kwh_per_day=6.0, heating=True, weather_scaled=True, noise_sigma=0.1,
    ),
    DeviceCategory.WATER_HEATER: CategorySpec(
        DeviceCategory.WATER_HEATER, Archetype.THERMOSTATIC, "Water heater (DHW)",
        default_kwh_per_day=4.0, is_dhw=True, tod_weights=_MORNING_EVENING,
        weather_scaled=False, noise_sigma=0.08,
    ),
    DeviceCategory.LIGHTING: CategorySpec(
        DeviceCategory.LIGHTING, Archetype.OCCUPANCY_DRIVEN, "Lighting",
        default_kwh_per_day=1.5, tod_weights=_MORNING_EVENING, noise_sigma=0.06,
    ),
    DeviceCategory.TV: CategorySpec(
        DeviceCategory.TV, Archetype.OCCUPANCY_DRIVEN, "TV / entertainment",
        default_kwh_per_day=1.0, tod_weights=_EVENING, noise_sigma=0.08,
    ),
    DeviceCategory.COMPUTER: CategorySpec(
        DeviceCategory.COMPUTER, Archetype.OCCUPANCY_DRIVEN, "Computer / office",
        default_kwh_per_day=1.2, tod_weights=_DAYTIME, noise_sigma=0.08,
    ),
    DeviceCategory.OVEN: CategorySpec(
        DeviceCategory.OVEN, Archetype.OCCUPANCY_DRIVEN, "Oven / stove",
        default_kwh_per_day=1.5, tod_weights=_MEALS, noise_sigma=0.15,
    ),
    DeviceCategory.SMALL_APPLIANCE: CategorySpec(
        DeviceCategory.SMALL_APPLIANCE, Archetype.OCCUPANCY_DRIVEN, "Kettle / microwave",
        default_kwh_per_day=0.6, tod_weights=_MEALS, noise_sigma=0.12,
    ),
    DeviceCategory.DISHWASHER: CategorySpec(
        DeviceCategory.DISHWASHER, Archetype.CYCLIC, "Dishwasher",
        default_kwh_per_day=1.0, cycle_kwh=1.0, cycle_hours=2, tod_weights=_EVENING,
        noise_sigma=0.1,
    ),
    DeviceCategory.WASHING_MACHINE: CategorySpec(
        DeviceCategory.WASHING_MACHINE, Archetype.CYCLIC, "Washing machine",
        default_kwh_per_day=0.7, cycle_kwh=1.0, cycle_hours=2, tod_weights=_DAYTIME,
        noise_sigma=0.1,
    ),
    DeviceCategory.DRYER: CategorySpec(
        DeviceCategory.DRYER, Archetype.CYCLIC, "Tumble dryer",
        default_kwh_per_day=1.2, cycle_kwh=2.5, cycle_hours=2, tod_weights=_DAYTIME,
        noise_sigma=0.1,
    ),
    DeviceCategory.EV_CHARGER: CategorySpec(
        DeviceCategory.EV_CHARGER, Archetype.EV_CHARGER, "EV charger",
        default_kwh_per_day=8.0, charger_kw=7.4, session_kwh=12.0, tod_weights=_EVENING,
        noise_sigma=0.1,
    ),
}


# --------------------------------------------------------------------------- #
# Lifestyle presets — hourly occupancy/activity in [0, 1] for weekday & weekend.
# Drives OCCUPANCY_DRIVEN devices, CYCLIC run probability, DHW draws, and the
# EV charge-day pattern.
# --------------------------------------------------------------------------- #


@dataclass(frozen=True)
class LifestyleSpec:
    preset: LifestylePreset
    label: str
    occ_weekday: tuple[float, ...]
    occ_weekend: tuple[float, ...]
    # Probability that an EV charging session happens on a given day.
    ev_charge_day_prob: float = 0.55
    # Baseline probability the household takes a multi-day trip in a given week.
    away_week_prob: float = 0.05


LIFESTYLE_SPECS: dict[LifestylePreset, LifestyleSpec] = {
    LifestylePreset.FAMILY_WITH_KIDS: LifestyleSpec(
        LifestylePreset.FAMILY_WITH_KIDS, "Family with kids",
        occ_weekday=(0.15, 0.1, 0.1, 0.1, 0.1, 0.2, 0.6, 0.85, 0.6, 0.4, 0.35, 0.4,
                     0.45, 0.4, 0.45, 0.6, 0.8, 0.95, 1.0, 1.0, 0.9, 0.6, 0.35, 0.2),
        occ_weekend=(0.2, 0.1, 0.1, 0.1, 0.1, 0.15, 0.3, 0.5, 0.75, 0.9, 0.95, 0.95,
                     0.9, 0.85, 0.85, 0.9, 0.9, 0.95, 1.0, 1.0, 0.9, 0.7, 0.45, 0.25),
        ev_charge_day_prob=0.6, away_week_prob=0.06,
    ),
    LifestylePreset.COUPLE_WORKING: LifestyleSpec(
        LifestylePreset.COUPLE_WORKING, "Couple, both working",
        occ_weekday=(0.15, 0.1, 0.1, 0.1, 0.1, 0.2, 0.6, 0.8, 0.5, 0.15, 0.1, 0.1,
                     0.1, 0.1, 0.1, 0.15, 0.3, 0.6, 0.9, 1.0, 0.95, 0.8, 0.5, 0.25),
        occ_weekend=(0.2, 0.1, 0.1, 0.1, 0.1, 0.15, 0.25, 0.4, 0.6, 0.8, 0.9, 0.9,
                     0.85, 0.8, 0.8, 0.85, 0.85, 0.9, 0.95, 1.0, 0.95, 0.8, 0.5, 0.3),
        ev_charge_day_prob=0.5, away_week_prob=0.08,
    ),
    LifestylePreset.WORK_FROM_HOME: LifestyleSpec(
        LifestylePreset.WORK_FROM_HOME, "Work from home",
        occ_weekday=(0.15, 0.1, 0.1, 0.1, 0.1, 0.2, 0.45, 0.7, 0.85, 0.9, 0.9, 0.9,
                     0.85, 0.9, 0.9, 0.85, 0.8, 0.8, 0.9, 1.0, 0.95, 0.8, 0.5, 0.25),
        occ_weekend=(0.2, 0.1, 0.1, 0.1, 0.1, 0.15, 0.3, 0.5, 0.7, 0.85, 0.9, 0.9,
                     0.85, 0.85, 0.85, 0.85, 0.85, 0.9, 0.95, 1.0, 0.9, 0.75, 0.5, 0.3),
        ev_charge_day_prob=0.45, away_week_prob=0.05,
    ),
    LifestylePreset.SINGLE: LifestyleSpec(
        LifestylePreset.SINGLE, "Single occupant",
        occ_weekday=(0.1, 0.05, 0.05, 0.05, 0.05, 0.15, 0.45, 0.6, 0.3, 0.1, 0.05, 0.05,
                     0.05, 0.05, 0.05, 0.1, 0.2, 0.45, 0.75, 0.9, 0.85, 0.7, 0.45, 0.2),
        occ_weekend=(0.15, 0.1, 0.05, 0.05, 0.05, 0.1, 0.15, 0.25, 0.45, 0.6, 0.7, 0.7,
                     0.6, 0.55, 0.55, 0.6, 0.6, 0.7, 0.8, 0.9, 0.9, 0.8, 0.55, 0.3),
        ev_charge_day_prob=0.4, away_week_prob=0.1,
    ),
    LifestylePreset.RETIRED: LifestyleSpec(
        LifestylePreset.RETIRED, "Retired / home all day",
        occ_weekday=(0.2, 0.1, 0.1, 0.1, 0.1, 0.2, 0.5, 0.75, 0.85, 0.9, 0.9, 0.9,
                     0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.95, 0.9, 0.75, 0.5, 0.3),
        occ_weekend=(0.2, 0.1, 0.1, 0.1, 0.1, 0.2, 0.5, 0.75, 0.85, 0.9, 0.9, 0.9,
                     0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.95, 0.9, 0.75, 0.5, 0.3),
        ev_charge_day_prob=0.35, away_week_prob=0.07,
    ),
    LifestylePreset.FREQUENTLY_AWAY: LifestyleSpec(
        LifestylePreset.FREQUENTLY_AWAY, "Frequently away / travels",
        occ_weekday=(0.1, 0.05, 0.05, 0.05, 0.05, 0.1, 0.3, 0.45, 0.2, 0.08, 0.05, 0.05,
                     0.05, 0.05, 0.05, 0.08, 0.15, 0.3, 0.5, 0.6, 0.55, 0.45, 0.3, 0.15),
        occ_weekend=(0.12, 0.08, 0.05, 0.05, 0.05, 0.08, 0.15, 0.25, 0.3, 0.4, 0.45, 0.45,
                     0.4, 0.4, 0.4, 0.4, 0.4, 0.45, 0.55, 0.6, 0.55, 0.45, 0.3, 0.15),
        ev_charge_day_prob=0.3, away_week_prob=0.25,
    ),
}


# --------------------------------------------------------------------------- #
# Sensible default device sets per room type (used by the frontend to prefill).
# --------------------------------------------------------------------------- #

ROOM_DEFAULT_DEVICES: dict[RoomType, list[DeviceCategory]] = {
    RoomType.KITCHEN: [
        DeviceCategory.REFRIGERATOR,
        DeviceCategory.OVEN,
        DeviceCategory.SMALL_APPLIANCE,
        DeviceCategory.DISHWASHER,
        DeviceCategory.LIGHTING,
    ],
    RoomType.LIVING_ROOM: [DeviceCategory.TV, DeviceCategory.LIGHTING, DeviceCategory.STANDBY],
    RoomType.BEDROOM: [DeviceCategory.LIGHTING, DeviceCategory.STANDBY],
    RoomType.BATHROOM: [DeviceCategory.LIGHTING, DeviceCategory.WATER_HEATER],
    RoomType.HOME_OFFICE: [DeviceCategory.COMPUTER, DeviceCategory.LIGHTING],
    RoomType.GARAGE: [DeviceCategory.EV_CHARGER, DeviceCategory.FREEZER],
    RoomType.UTILITY: [
        DeviceCategory.WASHING_MACHINE,
        DeviceCategory.DRYER,
        DeviceCategory.HEAT_PUMP,
        DeviceCategory.NETWORK,
    ],
    RoomType.HALLWAY: [DeviceCategory.LIGHTING],
    RoomType.OUTDOOR: [DeviceCategory.LIGHTING],
}
