"""Authentication pipeline: username/password login with JWT access tokens and
Redis-backed, revocable refresh sessions. No public registration — users are
seeded by an administrator at startup.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from uuid import UUID, uuid4

from redis.asyncio import Redis

from src.config import AuthSettings
from src.domain.errors import AuthTokenError, InvalidCredentialsError
from src.infra.security import decode_token, encode_token, verify_password
from src.models.api import TokenResponse
from src.repositories.user import UserRepository

_SESSION_PREFIX = "auth:refresh:"


class AuthPipeline:
    def __init__(self, users: UserRepository, redis: Redis, settings: AuthSettings) -> None:
        self._users = users
        self._redis = redis
        self._settings = settings

    async def login(self, username: str, password: str) -> TokenResponse:
        user = await self._users.get_by_username(username)
        if user is None or not verify_password(password, user.password_hash):
            raise InvalidCredentialsError()
        return await self._issue_tokens(user.id)

    async def refresh(self, refresh_token: str) -> TokenResponse:
        try:
            payload = decode_token(refresh_token, self._settings.jwt_secret)
        except Exception as exc:  # noqa: BLE001 - any jwt error is a token error
            raise AuthTokenError() from exc
        if payload.get("type") != "refresh":
            raise AuthTokenError("Not a refresh token")
        jti = payload.get("jti", "")
        user_id = await self._redis.get(_SESSION_PREFIX + jti)
        if user_id is None:
            raise AuthTokenError("Refresh session expired or revoked")
        # Rotate: revoke the old refresh token, issue a fresh pair.
        await self._redis.delete(_SESSION_PREFIX + jti)
        return await self._issue_tokens(UUID(user_id))

    async def logout(self, refresh_token: str) -> None:
        try:
            payload = decode_token(refresh_token, self._settings.jwt_secret)
        except Exception:  # noqa: BLE001
            return
        jti = payload.get("jti")
        if jti:
            await self._redis.delete(_SESSION_PREFIX + jti)

    def verify_access(self, access_token: str) -> UUID:
        try:
            payload = decode_token(access_token, self._settings.jwt_secret)
        except Exception as exc:  # noqa: BLE001
            raise AuthTokenError() from exc
        if payload.get("type") != "access":
            raise AuthTokenError("Not an access token")
        return UUID(payload["sub"])

    async def _issue_tokens(self, user_id: UUID) -> TokenResponse:
        now = datetime.now(tz=UTC)
        access_exp = now + timedelta(seconds=self._settings.access_ttl_seconds)
        access = encode_token(
            {
                "sub": str(user_id),
                "type": "access",
                "jti": uuid4().hex,
                "iat": int(now.timestamp()),
                "exp": int(access_exp.timestamp()),
            },
            self._settings.jwt_secret,
        )
        refresh_jti = uuid4().hex
        refresh = encode_token(
            {
                "sub": str(user_id),
                "type": "refresh",
                "jti": refresh_jti,
                "iat": int(now.timestamp()),
                "exp": int(
                    (now + timedelta(seconds=self._settings.refresh_ttl_seconds)).timestamp()
                ),
            },
            self._settings.jwt_secret,
        )
        await self._redis.setex(
            _SESSION_PREFIX + refresh_jti,
            self._settings.refresh_ttl_seconds,
            str(user_id),
        )
        return TokenResponse(
            access_token=access,
            refresh_token=refresh,
            expires_in=self._settings.access_ttl_seconds,
        )
