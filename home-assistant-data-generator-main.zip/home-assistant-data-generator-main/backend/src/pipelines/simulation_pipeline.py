"""Simulation pipeline: turns a stored config snapshot into a validated artifact
bundle, reporting progress/checkpoints to Redis along the way.

The engine itself is deterministic given the seed, so a job that is interrupted
can simply be re-run from the snapshot — there is no need to serialise partial
numpy state. Redis holds the live progress/phase; Postgres holds the durable run
record.
"""

from __future__ import annotations

import json
import logging
from datetime import date
from pathlib import Path
from uuid import UUID

from redis.asyncio import Redis

from src.domain.catalog import DeviceCategory, EstimatePeriod, LifestylePreset, RoomType
from src.domain.exporters.bundle import write_bundle
from src.domain.models import AwayPeriod, DeviceSpec, HouseholdSpec, SimulationConfig
from src.domain.simulator import simulate
from src.domain.validator import ValidationReport, validate
from src.repositories.weather_cache import WeatherCache

logger = logging.getLogger(__name__)

PROGRESS_PREFIX = "sim:progress:"
PROGRESS_TTL = 86400


def config_to_dict(config: SimulationConfig) -> dict:
    h = config.household
    return {
        "household": {
            "latitude": h.latitude,
            "longitude": h.longitude,
            "timezone": h.timezone,
            "start_date": h.start_date.isoformat(),
            "n_days": h.n_days,
            "lifestyle": h.lifestyle.value,
            "error_allowance_pct": h.error_allowance_pct,
            "holidays_country": h.holidays_country,
            "grid_sensor_id": h.grid_sensor_id,
            "master_seed": h.master_seed,
            "away_periods": [
                {"start": p.start.isoformat(), "end": p.end.isoformat()}
                for p in h.away_periods
            ],
        },
        "devices": [
            {
                "device_id": d.device_id,
                "name": d.name,
                "category": d.category.value,
                "room_type": d.room_type.value,
                "kwh_estimate": d.kwh_estimate,
                "estimate_period": d.estimate_period.value,
            }
            for d in config.devices
        ],
    }


def config_from_dict(data: dict) -> SimulationConfig:
    h = data["household"]
    household = HouseholdSpec(
        latitude=h["latitude"],
        longitude=h["longitude"],
        timezone=h["timezone"],
        start_date=date.fromisoformat(h["start_date"]),
        n_days=h["n_days"],
        lifestyle=LifestylePreset(h["lifestyle"]),
        error_allowance_pct=h["error_allowance_pct"],
        holidays_country=h["holidays_country"],
        grid_sensor_id=h["grid_sensor_id"],
        master_seed=h["master_seed"],
        away_periods=tuple(
            AwayPeriod(date.fromisoformat(p["start"]), date.fromisoformat(p["end"]))
            for p in h.get("away_periods", [])
        ),
    )
    devices = tuple(
        DeviceSpec(
            device_id=d["device_id"],
            name=d["name"],
            category=DeviceCategory(d["category"]),
            room_type=RoomType(d["room_type"]),
            kwh_estimate=d["kwh_estimate"],
            estimate_period=EstimatePeriod(d["estimate_period"]),
        )
        for d in data["devices"]
    )
    return SimulationConfig(household=household, devices=devices)


class SimulationPipeline:
    def __init__(self, redis: Redis, weather_cache: WeatherCache, artifact_dir: str) -> None:
        self._redis = redis
        self._weather = weather_cache
        self._artifact_dir = Path(artifact_dir)

    async def _set_progress(self, run_id: UUID, phase: str, progress: int) -> None:
        await self._redis.setex(
            PROGRESS_PREFIX + str(run_id),
            PROGRESS_TTL,
            json.dumps({"phase": phase, "progress": progress}),
        )

    async def get_progress(self, run_id: UUID) -> dict | None:
        raw = await self._redis.get(PROGRESS_PREFIX + str(run_id))
        return json.loads(raw) if raw else None

    async def delete_artifacts(self, run_id: UUID) -> None:
        """Remove a run's generated bundle (zip + working dir) and progress key."""
        import shutil

        out_dir = self._artifact_dir / str(run_id)
        shutil.rmtree(out_dir, ignore_errors=True)
        (self._artifact_dir / f"{run_id}.zip").unlink(missing_ok=True)
        await self._redis.delete(PROGRESS_PREFIX + str(run_id))

    async def run(self, run_id: UUID, config_json: dict) -> tuple[Path, ValidationReport]:
        """Execute the full pipeline. Raises on validation failure."""
        config = config_from_dict(config_json)
        household = config.household

        await self._set_progress(run_id, "weather", 10)
        weather_df = await self._weather.fetch(
            household.latitude, household.longitude, household.start_date, household.n_days
        )

        await self._set_progress(run_id, "simulate", 45)
        result = simulate(config, weather_df=weather_df)

        await self._set_progress(run_id, "validate", 70)
        has_thermostatic = any(
            DeviceCategory(d.category.value)
            in {
                DeviceCategory.HEAT_PUMP,
                DeviceCategory.AIR_CONDITIONER,
                DeviceCategory.ELECTRIC_HEATER,
            }
            for d in config.devices
        )
        report = validate(result, has_thermostatic=has_thermostatic)

        await self._set_progress(run_id, "export", 88)
        out_dir = self._artifact_dir / str(run_id)
        zip_path = write_bundle(result, household, out_dir)

        await self._set_progress(run_id, "completed", 100)
        return zip_path, report
