"""initial schema

Revision ID: 0001
Revises:
Create Date: 2026-06-20

"""
from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.dialects.postgresql import UUID as PgUUID

from alembic import op
from src.models.db import SCHEMA

revision: str = "0001"
down_revision: str | None = None
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "users",
        sa.Column("id", PgUUID(as_uuid=True), primary_key=True),
        sa.Column("username", sa.String(150), nullable=False, unique=True),
        sa.Column("password_hash", sa.String(255), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(),
                  nullable=False),
        schema=SCHEMA,
    )
    op.create_table(
        "households",
        sa.Column("id", PgUUID(as_uuid=True), primary_key=True),
        sa.Column("owner_user_id", PgUUID(as_uuid=True),
                  sa.ForeignKey(f"{SCHEMA}.users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("name", sa.String(200), nullable=False),
        sa.Column("latitude", sa.Float, nullable=False),
        sa.Column("longitude", sa.Float, nullable=False),
        sa.Column("timezone", sa.String(64), nullable=False),
        sa.Column("lifestyle", sa.String(64), nullable=False),
        sa.Column("holidays_country", sa.String(8), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(),
                  nullable=False),
        schema=SCHEMA,
    )
    op.create_table(
        "rooms",
        sa.Column("id", PgUUID(as_uuid=True), primary_key=True),
        sa.Column("household_id", PgUUID(as_uuid=True),
                  sa.ForeignKey(f"{SCHEMA}.households.id", ondelete="CASCADE"), nullable=False),
        sa.Column("name", sa.String(200), nullable=False),
        sa.Column("room_type", sa.String(64), nullable=False),
        schema=SCHEMA,
    )
    op.create_table(
        "devices",
        sa.Column("id", PgUUID(as_uuid=True), primary_key=True),
        sa.Column("room_id", PgUUID(as_uuid=True),
                  sa.ForeignKey(f"{SCHEMA}.rooms.id", ondelete="CASCADE"), nullable=False),
        sa.Column("name", sa.String(200), nullable=False),
        sa.Column("category", sa.String(64), nullable=False),
        sa.Column("kwh_estimate", sa.Float, nullable=False),
        sa.Column("estimate_period", sa.String(16), nullable=False),
        schema=SCHEMA,
    )
    op.create_table(
        "simulation_runs",
        sa.Column("id", PgUUID(as_uuid=True), primary_key=True),
        sa.Column("owner_user_id", PgUUID(as_uuid=True),
                  sa.ForeignKey(f"{SCHEMA}.users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("household_id", PgUUID(as_uuid=True), nullable=True),
        sa.Column("status", sa.String(32), nullable=False),
        sa.Column("phase", sa.String(32), nullable=False),
        sa.Column("progress", sa.Integer, nullable=False),
        sa.Column("n_days", sa.Integer, nullable=False),
        sa.Column("seed", sa.Integer, nullable=False),
        sa.Column("config_json", JSONB, nullable=False),
        sa.Column("validation_json", JSONB, nullable=True),
        sa.Column("artifact_path", sa.Text, nullable=True),
        sa.Column("error_message", sa.Text, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(),
                  nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(),
                  nullable=False),
        schema=SCHEMA,
    )
    op.create_index("ix_runs_owner", "simulation_runs", ["owner_user_id"], schema=SCHEMA)


def downgrade() -> None:
    op.drop_table("simulation_runs", schema=SCHEMA)
    op.drop_table("devices", schema=SCHEMA)
    op.drop_table("rooms", schema=SCHEMA)
    op.drop_table("households", schema=SCHEMA)
    op.drop_table("users", schema=SCHEMA)
