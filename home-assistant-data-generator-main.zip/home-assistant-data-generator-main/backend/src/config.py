from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import TypeVar
from urllib.parse import quote_plus

from pydantic import AliasChoices, BaseModel, Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class EnvSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=Path(__file__).parent.parent / ".env",
        env_file_encoding="utf-8",
        populate_by_name=True,
        validate_by_name=True,
        # Case-sensitive so short aliases (e.g. "user") don't collide with
        # ambient OS env vars like $USER; only the explicit *_* names match.
        case_sensitive=True,
        extra="ignore",
    )


T = TypeVar("T", bound=EnvSettings)


def type_to_default_factory(cls: type[T]) -> Callable[[], T]:
    def default_factory() -> T:
        return cls()

    return default_factory


class AppSettings(EnvSettings):
    name: str
    environment: str = Field("local", validation_alias=AliasChoices("environment", "APP_ENV"))
    log_level: str = Field("INFO", validation_alias=AliasChoices("log_level", "LOG_LEVEL"))
    port: int = Field(8080, validation_alias=AliasChoices("port", "HTTP_PORT"))
    cors_origins: str = Field(
        "http://localhost:3000",
        validation_alias=AliasChoices("cors_origins", "CORS_ORIGINS"),
    )

    @property
    def cors_origin_list(self) -> list[str]:
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]


class PostgresSettings(EnvSettings):
    host: str = Field(..., validation_alias=AliasChoices("host", "POSTGRES_HOST"))
    port: int = Field(5432, validation_alias=AliasChoices("port", "POSTGRES_PORT"))
    db: str = Field(..., validation_alias=AliasChoices("db", "POSTGRES_DB"))
    user: str = Field(..., validation_alias=AliasChoices("user", "POSTGRES_USER"))
    password: str = Field(..., validation_alias=AliasChoices("password", "POSTGRES_PASSWORD"))
    # Dedicated schema inside the shared cluster database — keeps our tables isolated.
    schema_name: str = Field(
        "energy_sim",
        validation_alias=AliasChoices("schema_name", "POSTGRES_SCHEMA"),
    )
    database_url: str | None = Field(
        None,
        validation_alias=AliasChoices("database_url", "DATABASE_URL"),
    )

    @property
    def dsn(self) -> str:
        if self.database_url:
            return self.database_url
        user = quote_plus(self.user)
        password = quote_plus(self.password)
        return f"postgresql+asyncpg://{user}:{password}@{self.host}:{self.port}/{self.db}"


class RedisSettings(EnvSettings):
    host: str = Field(..., validation_alias=AliasChoices("host", "REDIS_HOST"))
    port: int = Field(6379, validation_alias=AliasChoices("port", "REDIS_PORT"))
    password: str | None = Field(None, validation_alias=AliasChoices("password", "REDIS_PASSWORD"))

    @field_validator("password")
    @classmethod
    def blank_password_is_none(cls, value: str | None) -> str | None:
        return value or None

    @property
    def url(self) -> str:
        if self.password:
            password = quote_plus(self.password)
            return f"redis://:{password}@{self.host}:{self.port}/0"
        return f"redis://{self.host}:{self.port}/0"


class AuthSettings(EnvSettings):
    jwt_secret: str = Field(..., validation_alias=AliasChoices("jwt_secret", "JWT_SECRET"))
    access_ttl_seconds: int = Field(
        900,
        validation_alias=AliasChoices("access_ttl_seconds", "JWT_ACCESS_TTL_SECONDS"),
    )
    refresh_ttl_seconds: int = Field(
        604800,
        validation_alias=AliasChoices("refresh_ttl_seconds", "JWT_REFRESH_TTL_SECONDS"),
    )
    admin_username: str = Field(
        "admin",
        validation_alias=AliasChoices("admin_username", "ADMIN_USERNAME"),
    )
    admin_password: str = Field(
        ...,
        validation_alias=AliasChoices("admin_password", "ADMIN_PASSWORD"),
    )


class SimSettings(EnvSettings):
    artifact_dir: str = Field(
        "/tmp/ha-energy-sim",
        validation_alias=AliasChoices("artifact_dir", "SIM_ARTIFACT_DIR"),
    )
    weather_cache_dir: str = Field(
        "/tmp/ha-energy-sim/weather-cache",
        validation_alias=AliasChoices("weather_cache_dir", "SIM_WEATHER_CACHE_DIR"),
    )
    openmeteo_enabled: bool = Field(
        True,
        validation_alias=AliasChoices("openmeteo_enabled", "SIM_OPENMETEO_ENABLED"),
    )


class SentrySettings(EnvSettings):
    dsn: str | None = Field(None, validation_alias=AliasChoices("dsn", "SENTRY_DSN"))
    environment: str = Field(
        "local",
        validation_alias=AliasChoices("environment", "SENTRY_ENVIRONMENT"),
    )

    @field_validator("dsn")
    @classmethod
    def blank_dsn_is_none(cls, value: str | None) -> str | None:
        return value or None


class Settings(BaseModel):
    app: AppSettings
    postgres: PostgresSettings = Field(default_factory=type_to_default_factory(PostgresSettings))
    redis: RedisSettings = Field(default_factory=type_to_default_factory(RedisSettings))
    auth: AuthSettings = Field(default_factory=type_to_default_factory(AuthSettings))
    sim: SimSettings = Field(default_factory=type_to_default_factory(SimSettings))
    sentry: SentrySettings = Field(default_factory=type_to_default_factory(SentrySettings))
