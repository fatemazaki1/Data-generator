#!/usr/bin/env bash
# Build the backend + frontend images for the energy-data-gen app.
# Usage: ./build-and-push.sh <env>   (default: local)
#
# Local (kind/k3d/docker-desktop) pulls straight from the local Docker daemon;
# cloud envs should retag/push to Harbor (see platform-deployment conventions).
set -euo pipefail

ENV="${1:-local}"
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

case "$ENV" in
  local)   API_BASE="https://energy-gen-api.tail717864.ts.net" ;;  # Tailscale Funnel (valid cert)
  *)       API_BASE="https://energy-gen-api.${ENV}.example.com" ;;
esac

echo "Building backend image energy-data-gen-backend:0.1.0"
docker build -t energy-data-gen-backend:0.1.0 "$REPO_ROOT/backend"

echo "Building frontend image energy-data-gen-frontend:0.1.1 (API_BASE=$API_BASE)"
docker build \
  --build-arg "VITE_API_BASE=$API_BASE" \
  -t energy-data-gen-frontend:0.1.1 "$REPO_ROOT/frontend"

# For kind/k3d, load the images into the cluster node(s):
#   kind load docker-image energy-data-gen-backend:0.1.0 energy-data-gen-frontend:0.1.0
#   k3d image import energy-data-gen-backend:0.1.0 energy-data-gen-frontend:0.1.0 -c <cluster>
echo "Done. Load the images into your cluster if using kind/k3d."
