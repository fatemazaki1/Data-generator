# Deploying energy-data-gen to the Kubernetes cluster

This app is deployed the same way as any platform workload: a 7-file Helm bundle on
the shared `charts/app` chart, wired into the `platform-deployment` Helmfile.
It runs in its **own namespace** (`energy-data-gen-<env>`) and **reuses the
existing cluster Postgres and Redis** (cross-namespace, via FQDN). Our tables live in
a dedicated `energy_sim` schema inside the shared database, so there is no
collision with other apps' tables.

```
deploy/
├── services/energy-data-gen/            # backend bundle (Deployment, Ingress, ExternalSecret, …)
├── services/energy-data-gen-frontend/   # static SPA bundle (nginx)
├── namespaces.yaml                      # energy-data-gen-<env> namespace
├── vault-seed-energy-data-gen.yaml      # kv/energy-data-gen secrets to seed
├── helmfile-snippet.yaml                # two lines to add to the top-level helmfile
└── build-and-push.sh                    # build both images
```

## What it reuses (no new infra)

| Resource | How |
|---|---|
| Postgres | `postgres-rw.data-<env>.svc.cluster.local:5432`, db `energy`, user `app`, schema `energy_sim`. Password from `kv/postgres.app_password`. |
| Redis | `redis-master.data-<env>.svc.cluster.local:6379`. Password from `kv/redis.password`. |
| Vault / ESO | New path `kv/energy-data-gen` for JWT + admin credentials. |
| ingress-nginx / cert-manager | `energy-gen.<domain>` (frontend) and `energy-gen-api.<domain>` (backend), self-signed TLS locally. |

## One-time install (local)

1. **Copy the bundles into the deployment repo** (sibling on disk):
   ```bash
   cp -r deploy/services/energy-data-gen           ../platform-deployment/services/
   cp -r deploy/services/energy-data-gen-frontend  ../platform-deployment/services/
   ```

2. **Register the releases** — add to the *Application tier* block of
   `../platform-deployment/helmfile.yaml` (see `helmfile-snippet.yaml`):
   ```yaml
     - path: services/energy-data-gen/helmfile.yaml
     - path: services/energy-data-gen-frontend/helmfile.yaml
   ```

3. **Add the namespace** — append `namespaces.yaml` to
   `../platform-deployment/manifests/namespaces.yaml`, then:
   ```bash
   cd ../platform-deployment && ENV=local envsubst < manifests/namespaces.yaml | kubectl apply -f -
   ```

4. **Seed Vault** — append `vault-seed-energy-data-gen.yaml` (with real values) to
   `../platform-deployment/scripts/.local/vault-seed-local.yaml`, then:
   ```bash
   ./scripts/init-vault.sh local
   ```

5. **Build images** and load them into the cluster:
   ```bash
   ./deploy/build-and-push.sh local
   # kind:  kind load docker-image energy-data-gen-backend:0.1.0 energy-data-gen-frontend:0.1.0
   # k3d:   k3d image import energy-data-gen-backend:0.1.0 energy-data-gen-frontend:0.1.0 -c <cluster>
   ```

6. **Deploy**:
   ```bash
   cd ../platform-deployment
   helmfile -e local -l app=energy-data-gen diff
   helmfile -e local -l app=energy-data-gen apply
   helmfile -e local -l app=energy-data-gen-frontend apply
   ```

## Verify

```bash
kubectl -n energy-data-gen-local get pods,ingress,externalsecret
# Backend readiness (proves it reached Postgres + Redis):
curl -sk https://energy-gen-api.127-0-0-1.sslip.io/readiness
# UI:
open https://energy-gen.127-0-0-1.sslip.io
```

The backend runs `alembic upgrade head` on startup, which creates the
`energy_sim` schema + tables in the shared database and seeds the admin
user from `kv/energy-data-gen`. Log in, build a household, and generate.

## Notes
- NetworkPolicy is disabled on these workloads so the backend can reach the
  data namespace (DB/Redis) and the public Open-Meteo API. Scope it
  explicitly before enabling in a hardened environment.
- Generated artifacts are written to the pod's `/tmp` (ephemeral). A run that is
  interrupted is re-generated deterministically from its stored seed on restart;
  for durable artifacts across restarts, enable `persistence` in `resources.yaml`.
- `replicas` stays at 1: a single in-process job runner owns the artifact dir.
